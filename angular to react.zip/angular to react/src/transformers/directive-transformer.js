const { parse } = require('@babel/parser');
const traverse = require('@babel/traverse').default;
const generate = require('@babel/generator').default;
const t = require('@babel/types');

async function transformAngularDirective(content, filePath, options = {}) {
  try {
    const ast = parse(content, {
      sourceType: 'module',
      plugins: ['typescript', 'decorators-legacy', 'classProperties']
    });

    let directiveMetadata = {};
    let directiveClass = null;

    // Extract directive metadata and class
    traverse(ast, {
      Decorator(path) {
        if (t.isIdentifier(path.node.expression.callee, { name: 'Directive' })) {
          const properties = path.node.expression.arguments[0].properties;
          properties.forEach(prop => {
            if (t.isIdentifier(prop.key)) {
              const key = prop.key.name;
              if (key === 'selector') {
                directiveMetadata.selector = prop.value.value;
              } else if (key === 'exportAs') {
                directiveMetadata.exportAs = prop.value.value;
              }
            }
          });
        }
      },
      ClassDeclaration(path) {
        if (path.node.decorators && path.node.decorators.some(dec => 
          t.isCallExpression(dec.expression) && 
          t.isIdentifier(dec.expression.callee, { name: 'Directive' })
        )) {
          directiveClass = path.node;
        }
      }
    });

    if (!directiveClass) {
      throw new Error('No Angular directive found in file');
    }

    // Analyze directive class
    const { methods, properties, hostListeners, inputs, outputs } = analyzeDirectiveClass(directiveClass);
    
    // Determine directive type and generate appropriate React equivalent
    const directiveType = determineDirectiveType(directiveMetadata, methods, properties);
    
    let reactCode = '';
    let testCode = '';

    switch (directiveType) {
      case 'attribute-directive':
        ({ reactCode, testCode } = generateAttributeDirective(directiveClass, directiveMetadata, methods, properties, hostListeners, options));
        break;
      case 'structural-directive':
        ({ reactCode, testCode } = generateStructuralDirective(directiveClass, directiveMetadata, methods, properties, options));
        break;
      default:
        ({ reactCode, testCode } = generateCustomHook(directiveClass, directiveMetadata, methods, properties, options));
    }

    return {
      code: reactCode,
      testCode,
      metadata: { ...directiveMetadata, directiveType }
    };

  } catch (error) {
    console.error(`Error transforming directive ${filePath}:`, error);
    throw error;
  }
}

function analyzeDirectiveClass(directiveClass) {
  const methods = [];
  const properties = [];
  const hostListeners = [];
  const inputs = [];
  const outputs = [];

  directiveClass.body.body.forEach(member => {
    if (t.isClassProperty(member)) {
      const decorators = member.decorators || [];
      
      decorators.forEach(decorator => {
        if (t.isIdentifier(decorator.expression, { name: 'Input' })) {
          inputs.push({
            name: member.key.name,
            type: getPropertyType(member),
            value: member.value
          });
        } else if (t.isIdentifier(decorator.expression, { name: 'Output' })) {
          outputs.push({
            name: member.key.name,
            type: getPropertyType(member)
          });
        } else if (t.isCallExpression(decorator.expression) && 
                   t.isIdentifier(decorator.expression.callee, { name: 'HostListener' })) {
          hostListeners.push({
            event: decorator.expression.arguments[0].value,
            method: member.key.name,
            args: decorator.expression.arguments[1] ? decorator.expression.arguments[1].elements.map(el => el.value) : []
          });
        }
      });

      if (!decorators.length) {
        properties.push({
          name: member.key ? member.key.name : 'unknown',
          type: getPropertyType(member),
          value: member.value
        });
      }
    } else if (t.isClassMethod(member) && member.kind !== 'constructor') {
      methods.push({
        name: member.key ? member.key.name : 'unknown',
        params: member.value ? member.value.params : [],
        body: member.value ? member.value.body : null,
        isAsync: member.value ? member.value.async : false
      });
    }
  });

  return { methods, properties, hostListeners, inputs, outputs };
}

function determineDirectiveType(metadata, methods, properties) {
  // Check if it's a structural directive (selector starts with *)
  if (metadata.selector && metadata.selector.startsWith('[') && metadata.selector.endsWith(']')) {
    const selectorName = metadata.selector.slice(1, -1);
    if (selectorName.startsWith('*')) {
      return 'structural-directive';
    }
    return 'attribute-directive';
  }
  
  return 'custom-hook';
}

function generateAttributeDirective(directiveClass, metadata, methods, properties, hostListeners, options) {
  const directiveName = directiveClass.name.name.replace(/Directive$/, '');
  const hookName = `use${directiveName}`;
  
  const reactCode = `import { useEffect, useRef, useCallback } from 'react';

// Custom hook for ${directiveName} directive functionality
export const ${hookName} = (${generateHookParams(properties)}) => {
  const elementRef = useRef(null);

${generateHookState(properties)}

${generateHostListenerHandlers(hostListeners)}

${generateDirectiveMethods(methods)}

  useEffect(() => {
    const element = elementRef.current;
    if (!element) return;

${generateHostListenerAttachment(hostListeners)}

    return () => {
${generateHostListenerCleanup(hostListeners)}
    };
  }, [${generateDependencies(properties, hostListeners)}]);

  return {
    ref: elementRef,
${generateHookReturns(methods, properties)}
  };
};

// Higher-order component version (alternative usage)
export const with${directiveName} = (WrappedComponent) => {
  return React.forwardRef((props, ref) => {
    const directiveProps = ${hookName}(props);
    
    return (
      <WrappedComponent
        {...props}
        {...directiveProps}
        ref={ref}
      />
    );
  });
};`;

  const testCode = generateDirectiveTest(directiveName, hookName, methods, properties);
  
  return { reactCode, testCode };
}

function generateStructuralDirective(directiveClass, metadata, methods, properties, options) {
  const directiveName = directiveClass.name.name.replace(/Directive$/, '');
  const componentName = `${directiveName}Wrapper`;
  
  const reactCode = `import React, { useState, useEffect, useMemo } from 'react';

// Structural directive converted to React component
export const ${componentName} = ({ 
  children, 
${generateStructuralProps(properties)}
}) => {
${generateStructuralState(properties)}

${generateStructuralMethods(methods)}

  const shouldRender = useMemo(() => {
${generateStructuralLogic(methods, properties)}
  }, [${generateDependencies(properties)}]);

  if (!shouldRender) {
    return null;
  }

  return (
    <>
      {typeof children === 'function' ? children(${generateChildrenParams(properties)}) : children}
    </>
  );
};

// Hook version for programmatic usage
export const use${directiveName} = (${generateHookParams(properties)}) => {
${generateHookState(properties)}

${generateDirectiveMethods(methods)}

  return {
${generateHookReturns(methods, properties)}
  };
};`;

  const testCode = generateStructuralDirectiveTest(directiveName, componentName, methods, properties);
  
  return { reactCode, testCode };
}

function generateCustomHook(directiveClass, metadata, methods, properties, options) {
  const directiveName = directiveClass.name.name.replace(/Directive$/, '');
  const hookName = `use${directiveName}`;
  
  const reactCode = `import { useState, useCallback, useEffect } from 'react';

// Custom hook for ${directiveName} functionality
export const ${hookName} = (${generateHookParams(properties)}) => {
${generateHookState(properties)}

${generateDirectiveMethods(methods)}

  useEffect(() => {
    // Initialization logic from directive constructor/ngOnInit
${generateInitializationLogic(methods)}
  }, []);

  return {
${generateHookReturns(methods, properties)}
  };
};`;

  const testCode = generateCustomHookTest(directiveName, hookName, methods, properties);
  
  return { reactCode, testCode };
}

function generateHookParams(properties) {
  if (properties.length === 0) return '';
  return properties.map(prop => `${prop.name} = ${getDefaultValue(prop.type)}`).join(', ');
}

function generateHookState(properties) {
  return properties.map(prop => {
    const initialValue = prop.value ? generate(prop.value).code : getDefaultValue(prop.type);
    return `  const [${prop.name}, set${capitalize(prop.name)}] = useState(${initialValue});`;
  }).join('\n');
}

function generateHostListenerHandlers(hostListeners) {
  return hostListeners.map(listener => {
    return `  const handle${capitalize(listener.event)} = useCallback((event) => {
    // Original ${listener.method} logic
    ${listener.method}(${listener.args.map(arg => arg === '$event' ? 'event' : arg).join(', ')});
  }, []);`;
  }).join('\n\n');
}

function generateDirectiveMethods(methods) {
  return methods.map(method => {
    const params = method.params.map(p => p.name).join(', ');
    const bodyCode = generate(method.body).code;
    
    return `  const ${method.name} = useCallback(${method.isAsync ? 'async ' : ''}(${params}) => {
${bodyCode.slice(1, -1)} // Remove braces
  }, []);`;
  }).join('\n\n');
}

function generateHostListenerAttachment(hostListeners) {
  return hostListeners.map(listener => {
    return `    element.addEventListener('${listener.event}', handle${capitalize(listener.event)});`;
  }).join('\n');
}

function generateHostListenerCleanup(hostListeners) {
  return hostListeners.map(listener => {
    return `      element.removeEventListener('${listener.event}', handle${capitalize(listener.event)});`;
  }).join('\n');
}

function generateDependencies(properties, hostListeners = []) {
  const deps = properties.map(prop => prop.name);
  const listenerDeps = hostListeners.map(listener => `handle${capitalize(listener.event)}`);
  return [...deps, ...listenerDeps].join(', ');
}

function generateHookReturns(methods, properties) {
  const methodReturns = methods.map(m => `    ${m.name}`);
  const propertyReturns = properties.map(p => `    ${p.name}, set${capitalize(p.name)}`);
  return [...methodReturns, ...propertyReturns].join(',\n');
}

function generateStructuralProps(properties) {
  return properties.map(prop => `  ${prop.name}`).join(',\n');
}

function generateStructuralState(properties) {
  return properties.map(prop => {
    const initialValue = prop.value ? generate(prop.value).code : getDefaultValue(prop.type);
    return `  const [${prop.name}State, set${capitalize(prop.name)}State] = useState(${initialValue});`;
  }).join('\n');
}

function generateStructuralMethods(methods) {
  return methods.map(method => {
    const params = method.params.map(p => p.name).join(', ');
    const bodyCode = generate(method.body).code;
    
    return `  const ${method.name} = useCallback(${method.isAsync ? 'async ' : ''}(${params}) => {
${bodyCode.slice(1, -1)} // Remove braces
  }, []);`;
  }).join('\n\n');
}

function generateStructuralLogic(methods, properties) {
  // This is a simplified version - in practice, you'd analyze the directive logic
  return `    // Add structural directive logic here
    return true; // Placeholder - implement based on directive conditions`;
}

function generateChildrenParams(properties) {
  return properties.map(prop => prop.name).join(', ');
}

function generateInitializationLogic(methods) {
  const initMethod = methods.find(m => m.name === 'ngOnInit');
  if (initMethod) {
    const bodyCode = generate(initMethod.body).code;
    return bodyCode.slice(1, -1); // Remove braces
  }
  return '    // Initialization logic';
}

function generateDirectiveTest(directiveName, hookName, methods, properties) {
  return `import { renderHook, act } from '@testing-library/react';
import { ${hookName} } from './${directiveName}';

describe('${hookName}', () => {
  it('should initialize with correct default values', () => {
    const { result } = renderHook(() => ${hookName}());
    
    expect(result.current.ref).toBeDefined();
${properties.map(prop => `    expect(result.current.${prop.name}).toBeDefined();`).join('\n')}
  });

${methods.map(method => `
  it('should handle ${method.name} correctly', () => {
    const { result } = renderHook(() => ${hookName}());
    
    act(() => {
      result.current.${method.name}(/* test parameters */);
    });
    
    // Add assertions based on expected behavior
  });`).join('')}
});`;
}

function generateStructuralDirectiveTest(directiveName, componentName, methods, properties) {
  return `import React from 'react';
import { render, screen } from '@testing-library/react';
import { ${componentName} } from './${directiveName}';

describe('${componentName}', () => {
  it('should render children when conditions are met', () => {
    render(
      <${componentName}>
        <div data-testid="child">Test Content</div>
      </${componentName}>
    );
    
    expect(screen.getByTestId('child')).toBeInTheDocument();
  });

  it('should not render children when conditions are not met', () => {
    render(
      <${componentName} /* add props that make it not render */>
        <div data-testid="child">Test Content</div>
      </${componentName}>
    );
    
    expect(screen.queryByTestId('child')).not.toBeInTheDocument();
  });
});`;
}

function generateCustomHookTest(directiveName, hookName, methods, properties) {
  return `import { renderHook, act } from '@testing-library/react';
import { ${hookName} } from './${directiveName}';

describe('${hookName}', () => {
  it('should initialize correctly', () => {
    const { result } = renderHook(() => ${hookName}());
    
    expect(result.current).toBeDefined();
${properties.map(prop => `    expect(result.current.${prop.name}).toBeDefined();`).join('\n')}
  });

${methods.map(method => `
  it('should handle ${method.name} correctly', () => {
    const { result } = renderHook(() => ${hookName}());
    
    act(() => {
      result.current.${method.name}(/* test parameters */);
    });
    
    // Add assertions based on expected behavior
  });`).join('')}
});`;
}

function getPropertyType(member) {
  if (member.typeAnnotation) {
    return generate(member.typeAnnotation.typeAnnotation).code;
  }
  return 'any';
}

function getDefaultValue(type) {
  if (type.includes('string')) return "''";
  if (type.includes('number')) return '0';
  if (type.includes('boolean')) return 'false';
  if (type.includes('[]') || type.includes('Array')) return '[]';
  if (type.includes('{}') || type.includes('object')) return '{}';
  return 'null';
}

function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

module.exports = { transformAngularDirective };
