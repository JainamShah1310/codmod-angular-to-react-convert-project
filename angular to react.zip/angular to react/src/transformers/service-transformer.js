const { parse } = require('@babel/parser');
const traverse = require('@babel/traverse').default;
const generate = require('@babel/generator').default;
const t = require('@babel/types');

async function transformAngularService(content, filePath, options = {}) {
  try {
    const ast = parse(content, {
      sourceType: 'module',
      plugins: ['typescript', 'decorators-legacy', 'classProperties']
    });

    let serviceMetadata = {};
    let serviceClass = null;
    let httpClient = false;
    let dependencies = [];

    // Extract service metadata and class
    traverse(ast, {
      Decorator(path) {
        if (t.isIdentifier(path.node.expression.callee, { name: 'Injectable' })) {
          const arg = path.node.expression.arguments[0];
          if (arg && t.isObjectExpression(arg)) {
            arg.properties.forEach(prop => {
              if (t.isIdentifier(prop.key, { name: 'providedIn' })) {
                serviceMetadata.providedIn = prop.value.value;
              }
            });
          }
        }
      },
      ClassDeclaration(path) {
        if (path.node.decorators && path.node.decorators.some(dec => 
          t.isCallExpression(dec.expression) && 
          t.isIdentifier(dec.expression.callee, { name: 'Injectable' })
        )) {
          serviceClass = path.node;
        }
      },
      ImportDeclaration(path) {
        if (path.node.source.value === '@angular/common/http') {
          path.node.specifiers.forEach(spec => {
            if (t.isImportSpecifier(spec) && spec.imported.name === 'HttpClient') {
              httpClient = true;
            }
          });
        }
      }
    });

    if (!serviceClass) {
      throw new Error('No Angular service found in file');
    }

    // Analyze service class
    const { methods, properties, constructor } = analyzeServiceClass(serviceClass);
    
    // Determine service type and generate appropriate React equivalent
    const serviceType = determineServiceType(methods, properties, httpClient);
    
    let reactCode = '';
    let testCode = '';

    switch (serviceType) {
      case 'http-service':
        ({ reactCode, testCode } = generateHttpService(serviceClass, methods, properties, options));
        break;
      case 'state-service':
        ({ reactCode, testCode } = generateStateService(serviceClass, methods, properties, options));
        break;
      case 'utility-service':
        ({ reactCode, testCode } = generateUtilityService(serviceClass, methods, properties, options));
        break;
      default:
        ({ reactCode, testCode } = generateGenericService(serviceClass, methods, properties, options));
    }

    return {
      code: reactCode,
      testCode,
      metadata: { ...serviceMetadata, serviceType }
    };

  } catch (error) {
    console.error(`Error transforming service ${filePath}:`, error);
    throw error;
  }
}

function analyzeServiceClass(serviceClass) {
  const methods = [];
  const properties = [];
  let constructor = null;

  serviceClass.body.body.forEach(member => {
    if (t.isClassProperty(member)) {
      properties.push({
        name: member.key.name,
        type: getPropertyType(member),
        value: member.value,
        accessibility: member.accessibility
      });
    } else if (t.isClassMethod(member)) {
      if (member.kind === 'constructor') {
        constructor = {
          params: member.value ? member.value.params : [],
          body: member.value ? member.value.body : null
        };
      } else {
        methods.push({
          name: member.key ? member.key.name : 'unknown',
          params: member.value ? member.value.params : [],
          body: member.value ? member.value.body : null,
          isAsync: member.value ? member.value.async : false,
          returnType: getMethodReturnType(member),
          accessibility: member.accessibility
        });
      }
    }
  });

  return { methods, properties, constructor };
}

function determineServiceType(methods, properties, httpClient) {
  // Check if it's an HTTP service
  if (httpClient || methods.some(m => m.name.includes('get') || m.name.includes('post') || m.name.includes('put') || m.name.includes('delete'))) {
    return 'http-service';
  }
  
  // Check if it's a state management service
  if (properties.some(p => p.name.includes('Subject') || p.name.includes('BehaviorSubject')) ||
      methods.some(m => m.name.includes('subscribe') || m.name.includes('emit'))) {
    return 'state-service';
  }
  
  // Check if it's a utility service
  if (methods.length > 0 && properties.length === 0) {
    return 'utility-service';
  }
  
  return 'generic-service';
}

function generateHttpService(serviceClass, methods, properties, options) {
  const serviceName = serviceClass.name.name.replace(/Service$/, '');
  
  const reactCode = `import { useState, useEffect, useCallback } from 'react';
import axios from 'axios';

// Custom hook for ${serviceName} HTTP operations
export const use${serviceName} = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

${generateHttpMethods(methods)}

  return {
    loading,
    error,
${methods.map(m => `    ${m.name}`).join(',\n')}
  };
};

// Context for ${serviceName} (if needed for global state)
export const ${serviceName}Context = React.createContext();

export const ${serviceName}Provider = ({ children }) => {
  const ${serviceName.toLowerCase()}Service = use${serviceName}();
  
  return (
    <${serviceName}Context.Provider value={${serviceName.toLowerCase()}Service}>
      {children}
    </${serviceName}Context.Provider>
  );
};

export const use${serviceName}Context = () => {
  const context = useContext(${serviceName}Context);
  if (!context) {
    throw new Error('use${serviceName}Context must be used within a ${serviceName}Provider');
  }
  return context;
};`;

  const testCode = generateHttpServiceTest(serviceName, methods);
  
  return { reactCode, testCode };
}

function generateStateService(serviceClass, methods, properties, options) {
  const serviceName = serviceClass.name.name.replace(/Service$/, '');
  
  const reactCode = `import React, { createContext, useContext, useReducer, useCallback } from 'react';

// State interface
interface ${serviceName}State {
${properties.map(p => `  ${p.name}: ${p.type};`).join('\n')}
}

// Actions
type ${serviceName}Action = 
${generateStateActions(methods)};

// Reducer
const ${serviceName.toLowerCase()}Reducer = (state: ${serviceName}State, action: ${serviceName}Action): ${serviceName}State => {
  switch (action.type) {
${generateReducerCases(methods)}
    default:
      return state;
  }
};

// Initial state
const initial${serviceName}State: ${serviceName}State = {
${properties.map(p => `  ${p.name}: ${getInitialValue(p)}`).join(',\n')}
};

// Context
const ${serviceName}Context = createContext<{
  state: ${serviceName}State;
  dispatch: React.Dispatch<${serviceName}Action>;
} | null>(null);

// Provider
export const ${serviceName}Provider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(${serviceName.toLowerCase()}Reducer, initial${serviceName}State);

  return (
    <${serviceName}Context.Provider value={{ state, dispatch }}>
      {children}
    </${serviceName}Context.Provider>
  );
};

// Hook
export const use${serviceName} = () => {
  const context = useContext(${serviceName}Context);
  if (!context) {
    throw new Error('use${serviceName} must be used within a ${serviceName}Provider');
  }

  const { state, dispatch } = context;

${generateStateServiceMethods(methods)}

  return {
    ...state,
${methods.map(m => `    ${m.name}`).join(',\n')}
  };
};`;

  const testCode = generateStateServiceTest(serviceName, methods);
  
  return { reactCode, testCode };
}

function generateUtilityService(serviceClass, methods, properties, options) {
  const serviceName = serviceClass.name.name.replace(/Service$/, '');
  
  const reactCode = `// Utility functions for ${serviceName}
${methods.map(method => {
  const params = method.params.map(p => p.name).join(', ');
  const bodyCode = generate(method.body).code;
  
  return `export const ${method.name} = ${method.isAsync ? 'async ' : ''}(${params}) => {
${bodyCode.slice(1, -1)} // Remove braces
};`;
}).join('\n\n')}

// Custom hook wrapper (optional)
export const use${serviceName} = () => {
  return {
${methods.map(m => `    ${m.name}`).join(',\n')}
  };
};`;

  const testCode = generateUtilityServiceTest(serviceName, methods);
  
  return { reactCode, testCode };
}

function generateGenericService(serviceClass, methods, properties, options) {
  const serviceName = serviceClass.name.name.replace(/Service$/, '');
  
  const reactCode = `import React, { createContext, useContext, useState, useCallback } from 'react';

// ${serviceName} service as a custom hook
export const use${serviceName} = () => {
${properties.map(p => {
  const initialValue = p.value ? generate(p.value).code : getDefaultValue(p.type);
  return `  const [${p.name}, set${capitalize(p.name)}] = useState(${initialValue});`;
}).join('\n')}

${methods.map(method => {
  const params = method.params.map(p => p.name).join(', ');
  const bodyCode = generate(method.body).code;
  
  return `  const ${method.name} = useCallback(${method.isAsync ? 'async ' : ''}(${params}) => {
${bodyCode.slice(1, -1)} // Remove braces
  }, []);`;
}).join('\n\n')}

  return {
${properties.map(p => `    ${p.name}, set${capitalize(p.name)}`).join(',\n')},
${methods.map(m => `    ${m.name}`).join(',\n')}
  };
};

// Context version (if global state is needed)
const ${serviceName}Context = createContext(null);

export const ${serviceName}Provider = ({ children }) => {
  const ${serviceName.toLowerCase()}Service = use${serviceName}();
  
  return (
    <${serviceName}Context.Provider value={${serviceName.toLowerCase()}Service}>
      {children}
    </${serviceName}Context.Provider>
  );
};

export const use${serviceName}Context = () => {
  const context = useContext(${serviceName}Context);
  if (!context) {
    throw new Error('use${serviceName}Context must be used within a ${serviceName}Provider');
  }
  return context;
};`;

  const testCode = generateGenericServiceTest(serviceName, methods);
  
  return { reactCode, testCode };
}

function generateHttpMethods(methods) {
  return methods.map(method => {
    const params = method.params.map(p => p.name).join(', ');
    const methodName = method.name;
    
    return `  const ${methodName} = useCallback(async (${params}) => {
    setLoading(true);
    setError(null);
    
    try {
      // Transform Angular HTTP call to axios
      const response = await axios.${getHttpMethod(methodName)}(/* URL and data based on original method */);
      return response.data;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);`;
  }).join('\n\n');
}

function generateStateActions(methods) {
  return methods.map(method => {
    const actionType = method.name.toUpperCase().replace(/([A-Z])/g, '_$1').replace(/^_/, '');
    return `  | { type: '${actionType}'; payload?: any }`;
  }).join('\n');
}

function generateReducerCases(methods) {
  return methods.map(method => {
    const actionType = method.name.toUpperCase().replace(/([A-Z])/g, '_$1').replace(/^_/, '');
    return `    case '${actionType}':
      // Transform original method logic to state update
      return { ...state, /* update based on action.payload */ };`;
  }).join('\n');
}

function generateStateServiceMethods(methods) {
  return methods.map(method => {
    const params = method.params.map(p => p.name).join(', ');
    const actionType = method.name.toUpperCase().replace(/([A-Z])/g, '_$1').replace(/^_/, '');
    
    return `  const ${method.name} = useCallback((${params}) => {
    dispatch({ type: '${actionType}', payload: { ${params} } });
  }, [dispatch]);`;
  }).join('\n\n');
}

function generateHttpServiceTest(serviceName, methods) {
  return `import { renderHook, act } from '@testing-library/react';
import axios from 'axios';
import { use${serviceName} } from './${serviceName}';

jest.mock('axios');
const mockedAxios = axios as jest.Mocked<typeof axios>;

describe('use${serviceName}', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should initialize with correct default state', () => {
    const { result } = renderHook(() => use${serviceName}());
    
    expect(result.current.loading).toBe(false);
    expect(result.current.error).toBe(null);
  });

${methods.map(method => `
  it('should handle ${method.name} successfully', async () => {
    const mockData = { id: 1, name: 'test' };
    mockedAxios.${getHttpMethod(method.name)}.mockResolvedValue({ data: mockData });
    
    const { result } = renderHook(() => use${serviceName}());
    
    await act(async () => {
      const response = await result.current.${method.name}();
      expect(response).toEqual(mockData);
    });
    
    expect(result.current.loading).toBe(false);
    expect(result.current.error).toBe(null);
  });`).join('')}
});`;
}

function generateStateServiceTest(serviceName, methods) {
  return `import React from 'react';
import { renderHook, act } from '@testing-library/react';
import { ${serviceName}Provider, use${serviceName} } from './${serviceName}';

const wrapper = ({ children }: { children: React.ReactNode }) => (
  <${serviceName}Provider>{children}</${serviceName}Provider>
);

describe('use${serviceName}', () => {
  it('should initialize with correct default state', () => {
    const { result } = renderHook(() => use${serviceName}(), { wrapper });
    
    // Add assertions based on initial state
    expect(result.current).toBeDefined();
  });

${methods.map(method => `
  it('should handle ${method.name} correctly', () => {
    const { result } = renderHook(() => use${serviceName}(), { wrapper });
    
    act(() => {
      result.current.${method.name}(/* test parameters */);
    });
    
    // Add assertions based on expected state changes
  });`).join('')}
});`;
}

function generateUtilityServiceTest(serviceName, methods) {
  return `import { ${methods.map(m => m.name).join(', ')} } from './${serviceName}';

describe('${serviceName} utilities', () => {
${methods.map(method => `
  describe('${method.name}', () => {
    it('should work correctly', () => {
      // Add test implementation based on method logic
      expect(${method.name}).toBeDefined();
    });
  });`).join('')}
});`;
}

function generateGenericServiceTest(serviceName, methods) {
  return `import { renderHook, act } from '@testing-library/react';
import { use${serviceName} } from './${serviceName}';

describe('use${serviceName}', () => {
  it('should initialize correctly', () => {
    const { result } = renderHook(() => use${serviceName}());
    
    expect(result.current).toBeDefined();
  });

${methods.map(method => `
  it('should handle ${method.name} correctly', () => {
    const { result } = renderHook(() => use${serviceName}());
    
    act(() => {
      result.current.${method.name}(/* test parameters */);
    });
    
    // Add assertions based on expected behavior
  });`).join('')}
});`;
}

function getPropertyType(member) {
  if (member.typeAnnotation) {
    return generate(member.typeAnnotation.typeAnnotation).code;
  }
  return 'any';
}

function getMethodReturnType(member) {
  if (member.returnType) {
    return generate(member.returnType.typeAnnotation).code;
  }
  return 'any';
}

function getHttpMethod(methodName) {
  const name = methodName.toLowerCase();
  if (name.includes('get') || name.includes('fetch') || name.includes('load')) return 'get';
  if (name.includes('post') || name.includes('create')) return 'post';
  if (name.includes('put') || name.includes('update')) return 'put';
  if (name.includes('delete') || name.includes('remove')) return 'delete';
  return 'get';
}

function getInitialValue(property) {
  if (property.value) {
    return generate(property.value).code;
  }
  return getDefaultValue(property.type);
}

function getDefaultValue(type) {
  if (type.includes('string')) return "''";
  if (type.includes('number')) return '0';
  if (type.includes('boolean')) return 'false';
  if (type.includes('[]') || type.includes('Array')) return '[]';
  if (type.includes('{}') || type.includes('object')) return '{}';
  return 'null';
}

function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

module.exports = { transformAngularService };
