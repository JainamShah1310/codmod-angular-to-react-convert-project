import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { UserProfileComponent } from './user-profile.component';
import { HighlightDirective } from './highlight.directive';
import { TruncatePipe } from './truncate.pipe';
import { UserService } from './user.service';

const routes: Routes = [
  { path: '', component: UserProfileComponent },
  { path: 'profile/:id', component: UserProfileComponent },
  { path: '**', redirectTo: '' }
];

@NgModule({
  declarations: [
    UserProfileComponent,
    HighlightDirective,
    TruncatePipe
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  providers: [
    UserService
  ],
  exports: [
    UserProfileComponent,
    HighlightDirective,
    TruncatePipe
  ]
})
export class UserModule { }