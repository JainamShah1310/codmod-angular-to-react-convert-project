const cheerio = require('cheerio');
const { analyzeTemplateFeatures } = require('../analyzers/project-analyzer');

async function transformAngularTemplate(templateContent, filePath, options = {}) {
  if (!templateContent || templateContent.trim() === '') {
    return { code: '    <div>No template content</div>' };
  }

  try {
    // Load the template into cheerio for parsing
    const $ = cheerio.load(templateContent, {
      xmlMode: false,
      decodeEntities: false,
      lowerCaseAttributeNames: false
    });

    // Analyze template features
    const features = analyzeTemplateFeatures(templateContent);

    // Transform the template
    const transformedHtml = transformElement($('body').length ? $('body') : $.root(), $, features);

    // Clean up and format JSX
    let jsxContent = transformedHtml
      .replace(/class=/g, 'className=')
      .replace(/for=/g, 'htmlFor=')
      .replace(/<!--[\s\S]*?-->/g, '') // Remove HTML comments
      .replace(/\s+/g, ' ')
      .trim();

    // Add proper indentation
    jsxContent = formatJSX(jsxContent);

    return {
      code: jsxContent,
      features,
      warnings: []
    };

  } catch (error) {
    console.error(`Error transforming template ${filePath}:`, error);
    return {
      code: '    <div>Error transforming template</div>',
      features: {},
      warnings: [error.message]
    };
  }
}

function transformElement(element, $, features) {
  let result = '';

  element.contents().each((index, node) => {
    if (node.type === 'text') {
      const text = $(node).text().trim();
      if (text) {
        // Transform Angular interpolation
        const transformedText = transformInterpolation(text);
        result += transformedText;
      }
    } else if (node.type === 'tag') {
      const $node = $(node);
      const tagName = node.name;
      
      // Handle special Angular elements
      if (tagName === 'ng-container') {
        result += transformNgContainer($node, $, features);
      } else if (tagName === 'ng-template') {
        result += transformNgTemplate($node, $, features);
      } else if (tagName === 'router-outlet') {
        result += transformRouterOutlet($node);
      } else {
        result += transformRegularElement($node, $, features);
      }
    }
  });

  return result;
}

function transformRegularElement($node, $, features) {
  const tagName = $node[0].name;
  const attributes = transformAttributes($node, features);
  const children = transformElement($node, $, features);
  
  // Self-closing tags
  const selfClosingTags = ['img', 'br', 'hr', 'input', 'meta', 'link', 'area', 'base', 'col', 'embed', 'source', 'track', 'wbr'];
  
  if (selfClosingTags.includes(tagName.toLowerCase())) {
    return `<${tagName}${attributes} />`;
  }
  
  return `<${tagName}${attributes}>${children}</${tagName}>`;
}

function transformAttributes($node, features) {
  let attributes = '';
  const attrs = $node[0].attribs || {};
  
  Object.keys(attrs).forEach(attrName => {
    const attrValue = attrs[attrName];
    
    // Transform Angular-specific attributes
    if (attrName.startsWith('*ng')) {
      attributes += transformStructuralDirective(attrName, attrValue);
    } else if (attrName.startsWith('(') && attrName.endsWith(')')) {
      attributes += transformEventBinding(attrName, attrValue);
    } else if (attrName.startsWith('[') && attrName.endsWith(']')) {
      attributes += transformPropertyBinding(attrName, attrValue);
    } else if (attrName.startsWith('[(') && attrName.endsWith(')]')) {
      attributes += transformTwoWayBinding(attrName, attrValue);
    } else if (attrName === 'ngClass') {
      attributes += transformNgClass(attrValue);
    } else if (attrName === 'ngStyle') {
      attributes += transformNgStyle(attrValue);
    } else if (attrName === 'routerLink') {
      attributes += transformRouterLink(attrValue);
    } else {
      // Regular attributes
      attributes += transformRegularAttribute(attrName, attrValue);
    }
  });
  
  return attributes;
}

function transformStructuralDirective(attrName, attrValue) {
  if (attrName === '*ngFor') {
    return transformNgFor(attrValue);
  } else if (attrName === '*ngIf') {
    return transformNgIf(attrValue);
  } else if (attrName === '*ngSwitch') {
    return transformNgSwitch(attrValue);
  }
  return '';
}

function transformNgFor(expression) {
  // Transform "let item of items; index as i" to React map
  const match = expression.match(/let\s+(\w+)\s+of\s+([^;]+)(?:;\s*index\s+as\s+(\w+))?/);
  if (match) {
    const [, itemVar, arrayExpr, indexVar] = match;
    const indexParam = indexVar ? `, ${indexVar}` : '';
    return ` data-ng-for="${arrayExpr}.map((${itemVar}${indexParam}) => "`;
  }
  return ` data-ng-for-error="Invalid ngFor expression"`;
}

function transformNgIf(expression) {
  return ` data-ng-if="{${expression} && "`;
}

function transformNgSwitch(expression) {
  return ` data-ng-switch="${expression}"`;
}

function transformEventBinding(attrName, attrValue) {
  const eventName = attrName.slice(1, -1); // Remove parentheses
  const reactEventName = getReactEventName(eventName);
  return ` ${reactEventName}={${transformEventHandler(attrValue)}}`;
}

function transformPropertyBinding(attrName, attrValue) {
  const propName = attrName.slice(1, -1); // Remove brackets
  const reactPropName = getReactPropName(propName);
  return ` ${reactPropName}={${attrValue}}`;
}

function transformTwoWayBinding(attrName, attrValue) {
  const propName = attrName.slice(2, -2); // Remove [( )]
  if (propName === 'ngModel') {
    return ` value={${attrValue}} onChange={(e) => set${capitalize(attrValue)}(e.target.value)}`;
  }
  return ` ${propName}={${attrValue}}`;
}

function transformNgClass(expression) {
  // Transform ngClass to className with conditional logic
  if (expression.includes('{') && expression.includes('}')) {
    // Object syntax: {class1: condition1, class2: condition2}
    return ` className={classNames(${expression})}`;
  } else {
    // Simple expression
    return ` className={${expression}}`;
  }
}

function transformNgStyle(expression) {
  return ` style={${expression}}`;
}

function transformRouterLink(value) {
  return ` to={${value}}`;
}

function transformRegularAttribute(attrName, attrValue) {
  // Transform HTML attributes to React equivalents
  const reactAttrName = getReactAttributeName(attrName);
  
  if (attrValue === '' || attrValue === attrName) {
    // Boolean attributes
    return ` ${reactAttrName}`;
  } else {
    return ` ${reactAttrName}="${attrValue}"`;
  }
}

function transformNgContainer($node, $, features) {
  // ng-container becomes a React Fragment
  const children = transformElement($node, $, features);
  return `<React.Fragment>${children}</React.Fragment>`;
}

function transformNgTemplate($node, $, features) {
  // ng-template becomes a conditional render or component
  const children = transformElement($node, $, features);
  return `{/* Template: ${children} */}`;
}

function transformRouterOutlet($node) {
  return '<Outlet />';
}

function transformInterpolation(text) {
  // Transform Angular interpolation {{}} to JSX {}
  return text.replace(/\{\{([^}]+)\}\}/g, '{$1}');
}

function transformEventHandler(handler) {
  // Transform Angular event handlers to React
  if (handler.includes('$event')) {
    return handler.replace(/\$event/g, 'e');
  }
  return `() => ${handler}`;
}

function getReactEventName(angularEventName) {
  const eventMap = {
    'click': 'onClick',
    'change': 'onChange',
    'input': 'onInput',
    'submit': 'onSubmit',
    'focus': 'onFocus',
    'blur': 'onBlur',
    'keydown': 'onKeyDown',
    'keyup': 'onKeyUp',
    'mouseenter': 'onMouseEnter',
    'mouseleave': 'onMouseLeave',
    'scroll': 'onScroll'
  };
  
  return eventMap[angularEventName] || `on${capitalize(angularEventName)}`;
}

function getReactPropName(angularPropName) {
  const propMap = {
    'innerHTML': 'dangerouslySetInnerHTML',
    'textContent': 'children'
  };
  
  return propMap[angularPropName] || angularPropName;
}

function getReactAttributeName(htmlAttrName) {
  const attrMap = {
    'class': 'className',
    'for': 'htmlFor',
    'tabindex': 'tabIndex',
    'readonly': 'readOnly',
    'maxlength': 'maxLength',
    'cellpadding': 'cellPadding',
    'cellspacing': 'cellSpacing',
    'rowspan': 'rowSpan',
    'colspan': 'colSpan',
    'usemap': 'useMap',
    'frameborder': 'frameBorder'
  };
  
  return attrMap[htmlAttrName] || htmlAttrName;
}

function formatJSX(jsx) {
  // Basic JSX formatting with proper indentation
  let formatted = jsx;
  let indentLevel = 2; // Start with 2 spaces for component content
  
  // Split by tags and add proper indentation
  const lines = formatted.split(/(?=<[^/])|(?<=>[^<]*)/);
  const formattedLines = [];
  
  lines.forEach(line => {
    if (line.trim()) {
      if (line.startsWith('</')) {
        indentLevel -= 2;
      }
      
      formattedLines.push(' '.repeat(Math.max(0, indentLevel)) + line.trim());
      
      if (line.startsWith('<') && !line.includes('</') && !line.endsWith('/>')) {
        indentLevel += 2;
      }
    }
  });
  
  return formattedLines.join('\n');
}

function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

module.exports = { transformAngularTemplate };
