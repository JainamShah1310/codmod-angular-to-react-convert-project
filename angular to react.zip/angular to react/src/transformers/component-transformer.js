// Babel AST parsing and manipulation tools for TypeScript/JavaScript transformation
const { parse } = require('@babel/parser');
const traverse = require('@babel/traverse').default;
const generate = require('@babel/generator').default;
const t = require('@babel/types');

// File system operations and path utilities
const fs = require('fs-extra');
const path = require('path');

// Import related transformers and analyzers
const { transformAngularTemplate } = require('./template-transformer');
const { analyzeComponentDependencies } = require('../analyzers/project-analyzer');

/**
 * Transforms an Angular component to a React functional component
 * Handles @Component decorator, lifecycle methods, Input/Output properties, and templates
 * @param {string} content - The Angular component file content
 * @param {string} filePath - Path to the component file
 * @param {Object} options - Transformation options (TypeScript, test generation, etc.)
 * @returns {Object} Transformed React component code and metadata
 */
async function transformAngularComponent(content, filePath, options = {}) {
  try {
    // Step 1: Parse the Angular component file into an Abstract Syntax Tree (AST)
    // This allows us to programmatically analyze and extract Angular-specific constructs
    const ast = parse(content, {
      sourceType: 'module',
      plugins: ['typescript', 'decorators-legacy', 'classProperties']
    });

    // Initialize variables to store extracted component information
    let componentMetadata = {};  // Stores @Component decorator properties
    let componentClass = null;   // Stores the component class definition
    let templateContent = '';    // HTML template content
    let styleContent = '';       // CSS/SCSS style content

    // Step 2: Traverse the AST to extract Angular component metadata and class definition
    traverse(ast, {
      // Extract @Component decorator metadata (selector, template, styles, etc.)
      Decorator(path) {
        if (t.isIdentifier(path.node.expression.callee, { name: 'Component' })) {
          const properties = path.node.expression.arguments[0].properties;
          properties.forEach(prop => {
            if (t.isIdentifier(prop.key)) {
              const key = prop.key.name;
              // Extract component selector (used for React component naming)
              if (key === 'selector') {
                componentMetadata.selector = prop.value.value;
              // Extract external template file reference
              } else if (key === 'templateUrl') {
                componentMetadata.templateUrl = prop.value.value;
              // Extract inline template content
              } else if (key === 'template') {
                componentMetadata.template = prop.value.value;
              // Extract external style file references
              } else if (key === 'styleUrls') {
                componentMetadata.styleUrls = prop.value.elements.map(el => el.value);
              // Extract inline style content
              } else if (key === 'styles') {
                componentMetadata.styles = prop.value.elements.map(el => el.value);
              }
            }
          });
        }
      },
      // Find the component class definition that has the @Component decorator
      ClassDeclaration(path) {
        if (path.node.decorators && path.node.decorators.some(dec => 
          t.isCallExpression(dec.expression) && 
          t.isIdentifier(dec.expression.callee, { name: 'Component' })
        )) {
          componentClass = path.node;
        }
      }
    });

    if (!componentClass) {
      throw new Error('No Angular component found in file');
    }

    // Step 3: Load external template and style files referenced by the component
    // Angular components can have external HTML templates via templateUrl
    if (componentMetadata.templateUrl) {
      const templatePath = path.resolve(path.dirname(filePath), componentMetadata.templateUrl);
      if (await fs.pathExists(templatePath)) {
        templateContent = await fs.readFile(templatePath, 'utf8');
      }
    } else if (componentMetadata.template) {
      // Use inline template if no external file is specified
      templateContent = componentMetadata.template;
    }

    // Load external CSS/SCSS style files referenced by the component
    if (componentMetadata.styleUrls) {
      for (const styleUrl of componentMetadata.styleUrls) {
        const stylePath = path.resolve(path.dirname(filePath), styleUrl);
        if (await fs.pathExists(stylePath)) {
          const style = await fs.readFile(stylePath, 'utf8');
          styleContent += style + '\n';
        }
      }
    } else if (componentMetadata.styles) {
      // Use inline styles if no external files are specified
      styleContent = componentMetadata.styles.join('\n');
    }

    // Step 4: Transform Angular HTML template to JSX
    // This converts Angular template syntax (*ngIf, *ngFor, etc.) to React JSX
    const jsxContent = await transformAngularTemplate(templateContent, filePath, options);

    // Step 5: Generate the React functional component
    // Converts Angular class component to React functional component with hooks
    const reactComponent = generateReactComponent(
      componentClass,
      componentMetadata,
      jsxContent.code,
      styleContent,
      options
    );

    // Step 6: Generate test file for the React component
    // Creates Jest + React Testing Library tests based on the component structure
    const testCode = generateComponentTest(componentClass, componentMetadata, options);

    // Return the complete transformation result
    return {
      code: reactComponent,
      testCode,
      metadata: componentMetadata
    };

  } catch (error) {
    console.error(`Error transforming component ${filePath}:`, error);
    throw error;
  }
}

/**
 * Generates a React functional component from Angular component metadata
 * Converts Angular class-based component to modern React hooks pattern
 * @param {Object} componentClass - Angular component class AST node
 * @param {Object} metadata - Component metadata from @Component decorator
 * @param {string} jsxContent - Transformed JSX template content
 * @param {string} styleContent - CSS/SCSS styles content
 * @param {Object} options - Generation options
 * @returns {string} Generated React component code
 */
function generateReactComponent(componentClass, metadata, jsxContent, styleContent, options) {
  const componentName = componentClass.id.name;
  
  // Extract Angular component features to convert to React equivalents
  const props = extractComponentProps(componentClass);     // @Input() -> props
  const state = extractComponentState(componentClass);     // class properties -> useState
  const methods = extractComponentMethods(componentClass); // class methods -> functions
  const lifecycle = extractLifecycleMethods(componentClass); // ngOnInit, etc. -> useEffect

  // Build React imports based on what features are used
  let imports = [
    "import React, { useState, useEffect } from 'react';"
  ];

  // Import CSS file if styles exist
  if (styleContent) {
    imports.push(`import './${componentName}.css';`);
  }

  // Generate imports
  const dependencies = analyzeComponentDependencies(componentClass);
  const importsList = generateImports(dependencies.imports, lifecycle, state, options);
  imports = imports.concat(importsList);

  // Generate hooks
  const hooks = generateHooks(lifecycle, state, props, methods);

  
  // Generate event handlers
  const eventHandlers = generateEventHandlers(methods);
  
  // Generate component body
  const componentBody = `
function ${componentName}(${generatePropsInterface(properties)}) {
${hooks}

${eventHandlers}

  return (
${jsxContent || '    <div>Component content</div>'}
  );
}`;

  // Generate styles
  const styledComponent = styleContent ? generateStyledComponent(componentName, styleContent) : '';
  
  // Generate exports
  const exportStatement = `export default ${componentName};`;
  
  return `${imports}

${styledComponent}

${componentBody}

${exportStatement}`;
}

function analyzeComponentClass(componentClass) {
  const properties = [];
  const methods = [];
  const lifecycleMethods = [];
  const state = [];
  
  if (!componentClass || !componentClass.body || !componentClass.body.body) {
    return { properties, methods, lifecycleMethods, state };
  }
  
  componentClass.body.body.forEach(member => {
    if (t.isClassProperty(member)) {
      if (member.decorators && member.decorators.some(dec => 
        t.isIdentifier(dec.expression, { name: 'Input' }) ||
        t.isIdentifier(dec.expression, { name: 'Output' })
      )) {
        properties.push({
          name: member.key ? member.key.name : 'unknown',
          type: getPropertyType(member),
          decorator: getDecoratorName(member.decorators[0])
        });
      } else {
        state.push({
          name: member.key ? member.key.name : 'unknown',
          type: getPropertyType(member),
          value: member.value
        });
      }
    } else if (t.isClassMethod(member)) {
      const methodName = member.key ? member.key.name : 'unknown';
      if (isLifecycleMethod(methodName)) {
        lifecycleMethods.push({
          name: methodName,
          params: member.value.params,
          body: member.value.body
        });
      } else {
        methods.push({
          name: methodName,
          params: member.value.params,
          body: member.value.body,
          isAsync: member.value.async
        });
      }
    }
  });
  
  return { properties, methods, lifecycleMethods, state };
}

function generateImports(dependencies, lifecycleMethods, state, options) {
  const imports = [];
  
  // React imports
  const reactImports = ['React'];
  
  if (lifecycleMethods.some(m => m.name === 'ngOnInit' || m.name === 'ngOnDestroy')) {
    reactImports.push('useEffect');
  }
  
  if (state.length > 0) {
    reactImports.push('useState');
  }
  
  imports.push(`import ${reactImports.join(', ')} from 'react';`);
  
  // Other imports based on dependencies
  dependencies.imports.forEach(imp => {
    if (imp.from.startsWith('@angular/')) {
      // Skip Angular imports, they'll be replaced with React equivalents
      return;
    }
    imports.push(`import { ${imp.items.join(', ')} } from '${imp.from}';`);
  });
  
  return imports.join('\n');
}

function generateHooks(lifecycleMethods, state, properties, methods) {
  const hooks = [];
  
  // Generate useState hooks for component state
  state.forEach(stateItem => {
    const initialValue = stateItem.value ? generate(stateItem.value).code : 'null';
    hooks.push(`  const [${stateItem.name}, set${capitalize(stateItem.name)}] = useState(${initialValue});`);
  });
  
  // Generate useEffect hooks for lifecycle methods
  lifecycleMethods.forEach(lifecycle => {
    if (lifecycle.name === 'ngOnInit') {
      const bodyCode = generate(lifecycle.body).code;
      hooks.push(`  useEffect(() => {
${bodyCode.slice(1, -1)} // Remove braces
  }, []);`);
    } else if (lifecycle.name === 'ngOnDestroy') {
      const bodyCode = generate(lifecycle.body).code;
      hooks.push(`  useEffect(() => {
    return () => {
${bodyCode.slice(1, -1)} // Remove braces
    };
  }, []);`);
    }
  });
  
  return hooks.join('\n');
}

function generateEventHandlers(methods) {
  return methods.map(method => {
    const bodyCode = generate(method.body).code;
    const params = method.params.map(param => param.name).join(', ');
    
    return `  const ${method.name} = ${method.isAsync ? 'async ' : ''}(${params}) => {
${bodyCode.slice(1, -1)} // Remove braces
  };`;
  }).join('\n\n');
}

function generatePropsInterface(properties) {
  if (properties.length === 0) return '';
  
  const props = properties.map(prop => prop.name).join(', ');
  return `{ ${props} }`;
}

function generateStyledComponent(componentName, styleContent) {
  // Convert CSS to CSS-in-JS or styled-components
  // This is a simplified version - in practice, you'd want more sophisticated CSS parsing
  return `const Styled${componentName} = styled.div\`
${styleContent}
\`;`;
}

function generateComponentTest(componentClass, metadata, options) {
  const componentName = componentClass.name.name.replace(/Component$/, '');
  
  return `import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import ${componentName} from './${componentName}';

describe('${componentName}', () => {
  it('should render successfully', () => {
    render(<${componentName} />);
    expect(screen.getByTestId('${componentName.toLowerCase()}')).toBeInTheDocument();
  });

  it('should handle props correctly', () => {
    const testProps = {};
    render(<${componentName} {...testProps} />);
    // Add more specific tests based on component functionality
  });

  // Add more tests based on component methods and lifecycle
});`;
}

function getPropertyType(member) {
  if (member.typeAnnotation) {
    return generate(member.typeAnnotation.typeAnnotation).code;
  }
  return 'any';
}

function getDecoratorName(decorator) {
  if (t.isIdentifier(decorator.expression)) {
    return decorator.expression.name;
  } else if (t.isCallExpression(decorator.expression)) {
    return decorator.expression.callee.name;
  }
  return 'unknown';
}

function isLifecycleMethod(methodName) {
  const lifecycleMethods = [
    'ngOnInit', 'ngOnDestroy', 'ngOnChanges', 'ngDoCheck',
    'ngAfterContentInit', 'ngAfterContentChecked',
    'ngAfterViewInit', 'ngAfterViewChecked'
  ];
  return lifecycleMethods.includes(methodName);
}

function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

module.exports = { transformAngularComponent };
