import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { UserService } from './user.service';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {
  @Input() userId: string;
  @Output() userSelected = new EventEmitter<string>();

  user: any = null;
  loading = false;
  error: string | null = null;

  constructor(private userService: UserService) {}

  ngOnInit() {
    this.loadUser();
  }

  async loadUser() {
    if (!this.userId) return;
    
    this.loading = true;
    this.error = null;
    
    try {
      this.user = await this.userService.getUser(this.userId);
    } catch (err) {
      this.error = 'Failed to load user';
    } finally {
      this.loading = false;
    }
  }

  onSelectUser() {
    this.userSelected.emit(this.userId);
  }

  onUpdateUser(userData: any) {
    this.userService.updateUser(this.userId, userData);
  }
}