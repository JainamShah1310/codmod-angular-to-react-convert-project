// Core dependencies for file system operations and utilities
const fs = require('fs-extra');
const path = require('path');
const glob = require('glob');
const chalk = require('chalk');

// Import all transformation modules for converting Angular constructs to React
const { transformAngularComponent } = require('./transformers/component-transformer');
const { transformAngularService } = require('./transformers/service-transformer');
const { transformAngularTemplate } = require('./transformers/template-transformer');
const { transformAngularModule } = require('./transformers/module-transformer');
const { transformAngularDirective } = require('./transformers/directive-transformer');
const { transformAngularPipe } = require('./transformers/pipe-transformer');

// Project structure generation and analysis utilities
const { generateReactProject } = require('./generators/project-generator');
const { analyzeAngularProject } = require('./analyzers/project-analyzer');

/**
 * Main codemod class that orchestrates the transformation of Angular projects to React
 * Handles project analysis, file transformation, and React project generation
 */
class AngularToReactCodemod {
  /**
   * Initialize the codemod with configuration options
   * @param {Object} options - Configuration options for the transformation
   * @param {string} options.sourceDir - Source directory containing Angular files
   * @param {string} options.outputDir - Output directory for React files
   * @param {boolean} options.preserveStructure - Whether to preserve original directory structure
   * @param {boolean} options.generateTests - Whether to generate test files
   * @param {boolean} options.useTypeScript - Whether to generate TypeScript files
   * @param {string} options.reactVersion - Target React version
   */
  constructor(options = {}) {
    // Merge user options with sensible defaults
    this.options = {
      sourceDir: options.sourceDir || './src',
      outputDir: options.outputDir || './react-output',
      preserveStructure: options.preserveStructure !== false,
      generateTests: options.generateTests !== false,
      useTypeScript: options.useTypeScript !== false,
      reactVersion: options.reactVersion || '18',
      ...options
    };
    
    // Initialize statistics tracking for transformation results
    this.stats = {
      components: 0,    // Number of Angular components transformed
      services: 0,      // Number of Angular services transformed
      templates: 0,     // Number of Angular templates transformed
      modules: 0,       // Number of Angular modules transformed
      directives: 0,    // Number of Angular directives transformed
      pipes: 0,         // Number of Angular pipes transformed
      errors: []        // Array of transformation errors
    };
  }

  /**
   * Main transformation method that orchestrates the entire Angular to React conversion process
   * This is the entry point for the transformation workflow
   */
  async transform() {
    console.log(chalk.blue('🚀 Starting Angular to React transformation...'));
    
    try {
      // Step 1: Analyze the Angular project structure to identify all files and their types
      const analysis = await analyzeAngularProject(this.options.sourceDir);
      console.log(chalk.green(`📊 Analyzed ${analysis.totalFiles} files`));
      
      // Step 2: Create the output directory structure for the React project
      await fs.ensureDir(this.options.outputDir);
      
      // Step 3: Generate the complete React project structure (package.json, config files, etc.)
      await generateReactProject(this.options.outputDir, this.options);
      
      // Step 4: Transform all identified Angular files to their React equivalents
      await this.transformFiles(analysis);
      
      // Step 5: Generate a detailed transformation report for review
      this.generateReport();
      
      console.log(chalk.green('✅ Transformation completed successfully!'));
      
    } catch (error) {
      console.error(chalk.red('❌ Transformation failed:'), error.message);
      throw error;
    }
  }

  /**
   * Transform all Angular files identified during analysis to their React equivalents
   * Handles each file type (components, services, templates, etc.) with appropriate transformers
   * @param {Object} analysis - Analysis results containing categorized file lists
   */
  async transformFiles(analysis) {
    const { components, services, templates, modules, directives, pipes } = analysis;
    
    // Transform Angular components to React functional components with hooks
    for (const componentFile of components) {
      try {
        await this.transformComponent(componentFile);
        this.stats.components++;
      } catch (error) {
        this.stats.errors.push({ file: componentFile, error: error.message });
        console.warn(chalk.yellow(`⚠️  Failed to transform component: ${componentFile}`));
      }
    }
    
    // Transform Angular services to React custom hooks and context providers
    for (const serviceFile of services) {
      try {
        await this.transformService(serviceFile);
        this.stats.services++;
      } catch (error) {
        this.stats.errors.push({ file: serviceFile, error: error.message });
        console.warn(chalk.yellow(`⚠️  Failed to transform service: ${serviceFile}`));
      }
    }
    
    // Transform Angular HTML templates to JSX (usually embedded in components)
    for (const templateFile of templates) {
      try {
        await this.transformTemplate(templateFile);
        this.stats.templates++;
      } catch (error) {
        this.stats.errors.push({ file: templateFile, error: error.message });
        console.warn(chalk.yellow(`⚠️  Failed to transform template: ${templateFile}`));
      }
    }
    
    // Transform Angular modules to React context providers and routing configuration
    for (const moduleFile of modules) {
      try {
        await this.transformModule(moduleFile);
        this.stats.modules++;
      } catch (error) {
        this.stats.errors.push({ file: moduleFile, error: error.message });
        console.warn(chalk.yellow(`⚠️  Failed to transform module: ${moduleFile}`));
      }
    }
    
    // Transform Angular directives to React custom hooks or higher-order components
    for (const directiveFile of directives) {
      try {
        await this.transformDirective(directiveFile);
        this.stats.directives++;
      } catch (error) {
        this.stats.errors.push({ file: directiveFile, error: error.message });
        console.warn(chalk.yellow(`⚠️  Failed to transform directive: ${directiveFile}`));
      }
    }
    
    // Transform Angular pipes to React utility functions and custom hooks
    for (const pipeFile of pipes) {
      try {
        await this.transformPipe(pipeFile);
        this.stats.pipes++;
      } catch (error) {
        this.stats.errors.push({ file: pipeFile, error: error.message });
        console.warn(chalk.yellow(`⚠️  Failed to transform pipe: ${pipeFile}`));
      }
    }
  }

  async transformComponent(filePath) {
    const content = await fs.readFile(filePath, 'utf8');
    const transformed = await transformAngularComponent(content, filePath, this.options);
    
    const outputPath = this.getOutputPath(filePath, '.tsx');
    await fs.ensureDir(path.dirname(outputPath));
    await fs.writeFile(outputPath, transformed.code);
    
    // Generate test file if requested
    if (this.options.generateTests && transformed.testCode) {
      const testPath = outputPath.replace('.tsx', '.test.tsx');
      await fs.writeFile(testPath, transformed.testCode);
    }
  }

  async transformService(filePath) {
    const content = await fs.readFile(filePath, 'utf8');
    const transformed = await transformAngularService(content, filePath, this.options);
    
    const outputPath = this.getOutputPath(filePath, '.ts');
    await fs.ensureDir(path.dirname(outputPath));
    await fs.writeFile(outputPath, transformed.code);
    
    if (this.options.generateTests && transformed.testCode) {
      const testPath = outputPath.replace('.ts', '.test.ts');
      await fs.writeFile(testPath, transformed.testCode);
    }
  }

  async transformTemplate(filePath) {
    const content = await fs.readFile(filePath, 'utf8');
    const transformed = await transformAngularTemplate(content, filePath, this.options);
    
    // Templates are usually integrated into components, but we can save them separately for reference
    const outputPath = this.getOutputPath(filePath, '.jsx');
    await fs.ensureDir(path.dirname(outputPath));
    await fs.writeFile(outputPath, transformed.code);
  }

  async transformModule(filePath) {
    const content = await fs.readFile(filePath, 'utf8');
    const transformed = await transformAngularModule(content, filePath, this.options);
    
    const outputPath = this.getOutputPath(filePath, '.ts');
    await fs.ensureDir(path.dirname(outputPath));
    await fs.writeFile(outputPath, transformed.code);
  }

  async transformDirective(filePath) {
    const content = await fs.readFile(filePath, 'utf8');
    const transformed = await transformAngularDirective(content, filePath, this.options);
    
    const outputPath = this.getOutputPath(filePath, '.tsx');
    await fs.ensureDir(path.dirname(outputPath));
    await fs.writeFile(outputPath, transformed.code);
  }

  async transformPipe(filePath) {
    const content = await fs.readFile(filePath, 'utf8');
    const transformed = await transformAngularPipe(content, filePath, this.options);
    
    const outputPath = this.getOutputPath(filePath, '.ts');
    await fs.ensureDir(path.dirname(outputPath));
    await fs.writeFile(outputPath, transformed.code);
  }

  getOutputPath(inputPath, extension) {
    const relativePath = path.relative(this.options.sourceDir, inputPath);
    const parsedPath = path.parse(relativePath);
    const outputPath = path.join(
      this.options.outputDir,
      'src',
      parsedPath.dir,
      parsedPath.name + extension
    );
    return outputPath;
  }

  generateReport() {
    console.log(chalk.blue('\n📋 Transformation Summary:'));
    console.log(`  Components: ${this.stats.components}`);
    console.log(`  Services: ${this.stats.services}`);
    console.log(`  Templates: ${this.stats.templates}`);
    console.log(`  Modules: ${this.stats.modules}`);
    console.log(`  Directives: ${this.stats.directives}`);
    console.log(`  Pipes: ${this.stats.pipes}`);
    
    if (this.stats.errors.length > 0) {
      console.log(chalk.red(`\n❌ Errors: ${this.stats.errors.length}`));
      this.stats.errors.forEach(({ file, error }) => {
        console.log(chalk.red(`  ${file}: ${error}`));
      });
    }
    
    // Write detailed report to file
    const report = {
      timestamp: new Date().toISOString(),
      stats: this.stats,
      options: this.options
    };
    
    fs.writeFileSync(
      path.join(this.options.outputDir, 'transformation-report.json'),
      JSON.stringify(report, null, 2)
    );
  }
}

module.exports = { AngularToReactCodemod };
