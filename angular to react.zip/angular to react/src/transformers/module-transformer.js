const { parse } = require('@babel/parser');
const traverse = require('@babel/traverse').default;
const generate = require('@babel/generator').default;
const t = require('@babel/types');

async function transformAngularModule(content, filePath, options = {}) {
  try {
    const ast = parse(content, {
      sourceType: 'module',
      plugins: ['typescript', 'decorators-legacy', 'classProperties']
    });

    let moduleMetadata = {};
    let moduleClass = null;
    let isRoutingModule = false;
    let routes = [];

    // Extract module metadata and class
    traverse(ast, {
      Decorator(path) {
        if (t.isIdentifier(path.node.expression.callee, { name: 'NgModule' })) {
          const properties = path.node.expression.arguments[0].properties;
          properties.forEach(prop => {
            if (t.isIdentifier(prop.key)) {
              const key = prop.key.name;
              moduleMetadata[key] = extractArrayValues(prop.value);
            }
          });
        }
      },
      ClassDeclaration(path) {
        if (path.node.decorators && path.node.decorators.some(dec => 
          t.isCallExpression(dec.expression) && 
          t.isIdentifier(dec.expression.callee, { name: 'NgModule' })
        )) {
          moduleClass = path.node;
        }
      },
      CallExpression(path) {
        if (t.isMemberExpression(path.node.callee) &&
            t.isIdentifier(path.node.callee.object, { name: 'RouterModule' })) {
          isRoutingModule = true;
          if (path.node.arguments[0] && t.isArrayExpression(path.node.arguments[0])) {
            routes = extractRoutes(path.node.arguments[0]);
          }
        }
      }
    });

    if (!moduleClass) {
      throw new Error('No Angular module found in file');
    }

    let reactCode = '';
    let testCode = '';

    if (isRoutingModule) {
      ({ reactCode, testCode } = generateRoutingModule(moduleClass, moduleMetadata, routes, options));
    } else {
      ({ reactCode, testCode } = generateProviderModule(moduleClass, moduleMetadata, options));
    }

    return {
      code: reactCode,
      testCode,
      metadata: { ...moduleMetadata, isRoutingModule }
    };

  } catch (error) {
    console.error(`Error transforming module ${filePath}:`, error);
    throw error;
  }
}

function extractArrayValues(node) {
  if (t.isArrayExpression(node)) {
    return node.elements.map(element => {
      if (t.isIdentifier(element)) {
        return element.name;
      } else if (t.isStringLiteral(element)) {
        return element.value;
      }
      return generate(element).code;
    });
  }
  return [];
}

function extractRoutes(routesArray) {
  return routesArray.elements.map(route => {
    if (t.isObjectExpression(route)) {
      const routeObj = {};
      route.properties.forEach(prop => {
        if (t.isIdentifier(prop.key)) {
          const key = prop.key.name;
          if (t.isStringLiteral(prop.value)) {
            routeObj[key] = prop.value.value;
          } else if (t.isIdentifier(prop.value)) {
            routeObj[key] = prop.value.name;
          } else {
            routeObj[key] = generate(prop.value).code;
          }
        }
      });
      return routeObj;
    }
    return {};
  });
}

function generateRoutingModule(moduleClass, metadata, routes, options) {
  const moduleName = moduleClass.name.name.replace(/Module$/, '');
  
  const reactCode = `import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
${generateRouteImports(routes)}

// ${moduleName} routing configuration
export const ${moduleName}Routes = () => {
  return (
    <Routes>
${generateRouteElements(routes)}
    </Routes>
  );
};

// Route configuration object (for programmatic access)
export const ${moduleName.toLowerCase()}Routes = [
${generateRouteConfig(routes)}
];

// Navigation helper hooks
export const use${moduleName}Navigation = () => {
  const navigate = useNavigate();
  const location = useLocation();
  
  return {
    navigate,
    location,
    currentPath: location.pathname,
${generateNavigationMethods(routes)}
  };
};

export default ${moduleName}Routes;`;

  const testCode = generateRoutingModuleTest(moduleName, routes);
  
  return { reactCode, testCode };
}

function generateProviderModule(moduleClass, metadata, options) {
  const moduleName = moduleClass.name.name.replace(/Module$/, '');
  
  const reactCode = `import React, { createContext, useContext } from 'react';
${generateProviderImports(metadata)}

// ${moduleName} context and providers
interface ${moduleName}ContextType {
${generateContextInterface(metadata)}
}

const ${moduleName}Context = createContext<${moduleName}ContextType | null>(null);

// Provider component that wraps the module's functionality
export const ${moduleName}Provider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
${generateProviderState(metadata)}

  const contextValue: ${moduleName}ContextType = {
${generateContextValue(metadata)}
  };

  return (
    <${moduleName}Context.Provider value={contextValue}>
      {children}
    </${moduleName}Context.Provider>
  );
};

// Hook to use the module context
export const use${moduleName} = () => {
  const context = useContext(${moduleName}Context);
  if (!context) {
    throw new Error('use${moduleName} must be used within a ${moduleName}Provider');
  }
  return context;
};

// Individual service hooks (alternative to context)
${generateServiceHooks(metadata)}

export default ${moduleName}Provider;`;

  const testCode = generateProviderModuleTest(moduleName, metadata);
  
  return { reactCode, testCode };
}

function generateRouteImports(routes) {
  const components = routes
    .filter(route => route.component)
    .map(route => route.component)
    .filter((component, index, arr) => arr.indexOf(component) === index);
  
  return components.map(component => 
    `import ${component} from './${component}';`
  ).join('\n');
}

function generateRouteElements(routes) {
  return routes.map(route => {
    const path = route.path || '';
    const component = route.component;
    const redirectTo = route.redirectTo;
    
    if (redirectTo) {
      return `      <Route path="${path}" element={<Navigate to="${redirectTo}" replace />} />`;
    } else if (component) {
      return `      <Route path="${path}" element={<${component} />} />`;
    } else if (route.loadChildren) {
      // Lazy loading - convert to React.lazy
      return `      <Route path="${path}/*" element={<React.Suspense fallback={<div>Loading...</div>}><LazyComponent /></React.Suspense>} />`;
    }
    return `      <Route path="${path}" element={<div>Route not configured</div>} />`;
  }).join('\n');
}

function generateRouteConfig(routes) {
  return routes.map(route => {
    const routeStr = JSON.stringify(route, null, 2);
    return `  ${routeStr}`;
  }).join(',\n');
}

function generateNavigationMethods(routes) {
  return routes.map(route => {
    if (route.path && route.component) {
      const methodName = `goTo${route.component}`;
      return `    ${methodName}: () => navigate('${route.path}')`;
    }
    return '';
  }).filter(Boolean).join(',\n');
}

function generateProviderImports(metadata) {
  const imports = [];
  
  if (metadata.providers) {
    metadata.providers.forEach(provider => {
      imports.push(`import { ${provider} } from './${provider}';`);
    });
  }
  
  return imports.join('\n');
}

function generateContextInterface(metadata) {
  const interfaces = [];
  
  if (metadata.providers) {
    metadata.providers.forEach(provider => {
      interfaces.push(`  ${provider.toLowerCase()}: any;`);
    });
  }
  
  return interfaces.join('\n');
}

function generateProviderState(metadata) {
  const states = [];
  
  if (metadata.providers) {
    metadata.providers.forEach(provider => {
      states.push(`  const ${provider.toLowerCase()} = use${provider}();`);
    });
  }
  
  return states.join('\n');
}

function generateContextValue(metadata) {
  const values = [];
  
  if (metadata.providers) {
    metadata.providers.forEach(provider => {
      values.push(`    ${provider.toLowerCase()}`);
    });
  }
  
  return values.join(',\n');
}

function generateServiceHooks(metadata) {
  if (!metadata.providers) return '';
  
  return metadata.providers.map(provider => {
    return `export const use${provider}Service = () => {
  // Individual hook for ${provider}
  return use${provider}();
};`;
  }).join('\n\n');
}

function generateRoutingModuleTest(moduleName, routes) {
  return `import React from 'react';
import { render, screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import { ${moduleName}Routes } from './${moduleName}';

const renderWithRouter = (component: React.ReactElement) => {
  return render(
    <BrowserRouter>
      {component}
    </BrowserRouter>
  );
};

describe('${moduleName}Routes', () => {
  it('should render without crashing', () => {
    renderWithRouter(<${moduleName}Routes />);
  });

${routes.map(route => {
  if (route.path && route.component) {
    return `
  it('should render ${route.component} for path "${route.path}"', () => {
    window.history.pushState({}, '', '${route.path}');
    renderWithRouter(<${moduleName}Routes />);
    // Add specific assertions for ${route.component}
  });`;
  }
  return '';
}).filter(Boolean).join('')}
});`;
}

function generateProviderModuleTest(moduleName, metadata) {
  return `import React from 'react';
import { render, screen } from '@testing-library/react';
import { ${moduleName}Provider, use${moduleName} } from './${moduleName}';

const TestComponent = () => {
  const context = use${moduleName}();
  return <div data-testid="test-component">Context loaded</div>;
};

describe('${moduleName}Provider', () => {
  it('should provide context to children', () => {
    render(
      <${moduleName}Provider>
        <TestComponent />
      </${moduleName}Provider>
    );
    
    expect(screen.getByTestId('test-component')).toBeInTheDocument();
  });

  it('should throw error when used outside provider', () => {
    const consoleSpy = jest.spyOn(console, 'error').mockImplementation();
    
    expect(() => {
      render(<TestComponent />);
    }).toThrow('use${moduleName} must be used within a ${moduleName}Provider');
    
    consoleSpy.mockRestore();
  });
});`;
}

module.exports = { transformAngularModule };
