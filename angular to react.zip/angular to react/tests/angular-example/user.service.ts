import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private usersSubject = new BehaviorSubject<any[]>([]);
  public users$ = this.usersSubject.asObservable();

  constructor(private http: HttpClient) {}

  async getUser(id: string): Promise<any> {
    return this.http.get(`/api/users/${id}`).toPromise();
  }

  async updateUser(id: string, userData: any): Promise<any> {
    const result = await this.http.put(`/api/users/${id}`, userData).toPromise();
    this.refreshUsers();
    return result;
  }

  async createUser(userData: any): Promise<any> {
    const result = await this.http.post('/api/users', userData).toPromise();
    this.refreshUsers();
    return result;
  }

  async deleteUser(id: string): Promise<void> {
    await this.http.delete(`/api/users/${id}`).toPromise();
    this.refreshUsers();
  }

  private refreshUsers() {
    this.http.get<any[]>('/api/users').subscribe(users => {
      this.usersSubject.next(users);
    });
  }

  getUsersStream(): Observable<any[]> {
    return this.users$;
  }
}