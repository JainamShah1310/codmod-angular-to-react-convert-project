const fs = require('fs-extra');
const path = require('path');

async function generateReactProject(outputDir, options = {}) {
  // Create React project structure
  await createProjectStructure(outputDir);
  
  // Generate package.json
  await generatePackageJson(outputDir, options);
  
  // Generate TypeScript config
  if (options.useTypeScript) {
    await generateTsConfig(outputDir);
  }
  
  // Generate build configuration
  await generateBuildConfig(outputDir, options);
  
  // Generate index.html
  await generateIndexHtml(outputDir, options);
  
  // Generate main entry point
  await generateMainEntry(outputDir, options);
  
  // Generate App component
  await generateAppComponent(outputDir, options);
  
  // Generate common utilities
  await generateUtilities(outputDir, options);
  
  // Generate test setup
  if (options.generateTests) {
    await generateTestSetup(outputDir, options);
  }
}

async function createProjectStructure(outputDir) {
  const directories = [
    'src',
    'src/components',
    'src/hooks',
    'src/services',
    'src/utils',
    'src/types',
    'src/contexts',
    'src/pages',
    'src/assets',
    'src/styles',
    'public',
    'tests',
    '__tests__'
  ];
  
  for (const dir of directories) {
    await fs.ensureDir(path.join(outputDir, dir));
  }
}

async function generatePackageJson(outputDir, options) {
  const packageJson = {
    name: "react-app-converted",
    version: "0.1.0",
    private: true,
    dependencies: {
      "react": "^18.2.0",
      "react-dom": "^18.2.0",
      "react-router-dom": "^6.8.0",
      "axios": "^1.3.0",
      "@types/react": "^18.0.0",
      "@types/react-dom": "^18.0.0"
    },
    devDependencies: {
      "@testing-library/jest-dom": "^5.16.0",
      "@testing-library/react": "^13.4.0",
      "@testing-library/user-event": "^14.4.0",
      "@types/jest": "^29.4.0",
      "jest": "^29.4.0",
      "typescript": "^4.9.0",
      "vite": "^4.1.0",
      "@vitejs/plugin-react": "^3.1.0"
    },
    scripts: {
      "start": "vite",
      "build": "vite build",
      "test": "jest",
      "test:watch": "jest --watch",
      "lint": "eslint src --ext ts,tsx --report-unused-disable-directives --max-warnings 0",
      "preview": "vite preview"
    },
    eslintConfig: {
      extends: [
        "react-app",
        "react-app/jest"
      ]
    },
    browserslist: {
      production: [
        ">0.2%",
        "not dead",
        "not op_mini all"
      ],
      development: [
        "last 1 chrome version",
        "last 1 firefox version",
        "last 1 safari version"
      ]
    }
  };

  if (options.useTypeScript) {
    packageJson.dependencies["typescript"] = "^4.9.0";
  }

  await fs.writeJson(path.join(outputDir, 'package.json'), packageJson, { spaces: 2 });
}

async function generateTsConfig(outputDir) {
  const tsConfig = {
    compilerOptions: {
      target: "es5",
      lib: [
        "dom",
        "dom.iterable",
        "es6"
      ],
      allowJs: true,
      skipLibCheck: true,
      esModuleInterop: true,
      allowSyntheticDefaultImports: true,
      strict: true,
      forceConsistentCasingInFileNames: true,
      noFallthroughCasesInSwitch: true,
      module: "esnext",
      moduleResolution: "node",
      resolveJsonModule: true,
      isolatedModules: true,
      noEmit: true,
      jsx: "react-jsx"
    },
    include: [
      "src"
    ]
  };

  await fs.writeJson(path.join(outputDir, 'tsconfig.json'), tsConfig, { spaces: 2 });
}

async function generateBuildConfig(outputDir, options) {
  const viteConfig = `import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
    open: true
  },
  build: {
    outDir: 'build',
    sourcemap: true
  }
})`;

  await fs.writeFile(path.join(outputDir, 'vite.config.ts'), viteConfig);
}

async function generateIndexHtml(outputDir, options) {
  const indexHtml = `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <link rel="icon" href="/favicon.ico" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="theme-color" content="#000000" />
    <meta
      name="description"
      content="React app converted from Angular"
    />
    <title>React App</title>
  </head>
  <body>
    <noscript>You need to enable JavaScript to run this app.</noscript>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>`;

  await fs.writeFile(path.join(outputDir, 'public/index.html'), indexHtml);
}

async function generateMainEntry(outputDir, options) {
  const extension = options.useTypeScript ? 'tsx' : 'jsx';
  
  const mainContent = `import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import './styles/index.css';

const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);

root.render(
  <React.StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </React.StrictMode>
);`;

  await fs.writeFile(path.join(outputDir, `src/main.${extension}`), mainContent);
}

async function generateAppComponent(outputDir, options) {
  const extension = options.useTypeScript ? 'tsx' : 'jsx';
  
  const appContent = `import React from 'react';
import { Routes, Route } from 'react-router-dom';
import './styles/App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>React App (Converted from Angular)</h1>
        <p>
          This application has been converted from Angular to React.
        </p>
      </header>
      <main>
        <Routes>
          <Route path="/" element={<div>Home Page</div>} />
          <Route path="*" element={<div>Page Not Found</div>} />
        </Routes>
      </main>
    </div>
  );
}

export default App;`;

  await fs.writeFile(path.join(outputDir, `src/App.${extension}`), appContent);
}

async function generateUtilities(outputDir, options) {
  // Generate common utility functions
  const utilsContent = `// Common utility functions

export const classNames = (...classes: (string | undefined | null | false)[]): string => {
  return classes.filter(Boolean).join(' ');
};

export const formatDate = (date: Date | string, format = 'MM/dd/yyyy'): string => {
  const d = new Date(date);
  return new Intl.DateTimeFormat('en-US').format(d);
};

export const debounce = <T extends (...args: any[]) => any>(
  func: T,
  wait: number
): ((...args: Parameters<T>) => void) => {
  let timeout: NodeJS.Timeout;
  return (...args: Parameters<T>) => {
    clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), wait);
  };
};

export const throttle = <T extends (...args: any[]) => any>(
  func: T,
  limit: number
): ((...args: Parameters<T>) => void) => {
  let inThrottle: boolean;
  return (...args: Parameters<T>) => {
    if (!inThrottle) {
      func(...args);
      inThrottle = true;
      setTimeout(() => (inThrottle = false), limit);
    }
  };
};`;

  await fs.writeFile(path.join(outputDir, 'src/utils/index.ts'), utilsContent);

  // Generate HTTP client utility
  const httpContent = `import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios';

class HttpClient {
  private instance: AxiosInstance;

  constructor(baseURL?: string) {
    this.instance = axios.create({
      baseURL: baseURL || process.env.REACT_APP_API_BASE_URL || '/api',
      timeout: 10000,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    this.setupInterceptors();
  }

  private setupInterceptors(): void {
    // Request interceptor
    this.instance.interceptors.request.use(
      (config) => {
        // Add auth token if available
        const token = localStorage.getItem('authToken');
        if (token) {
          config.headers.Authorization = \`Bearer \${token}\`;
        }
        return config;
      },
      (error) => Promise.reject(error)
    );

    // Response interceptor
    this.instance.interceptors.response.use(
      (response) => response,
      (error) => {
        if (error.response?.status === 401) {
          // Handle unauthorized access
          localStorage.removeItem('authToken');
          window.location.href = '/login';
        }
        return Promise.reject(error);
      }
    );
  }

  async get<T = any>(url: string, config?: AxiosRequestConfig): Promise<T> {
    const response: AxiosResponse<T> = await this.instance.get(url, config);
    return response.data;
  }

  async post<T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<T> {
    const response: AxiosResponse<T> = await this.instance.post(url, data, config);
    return response.data;
  }

  async put<T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<T> {
    const response: AxiosResponse<T> = await this.instance.put(url, data, config);
    return response.data;
  }

  async delete<T = any>(url: string, config?: AxiosRequestConfig): Promise<T> {
    const response: AxiosResponse<T> = await this.instance.delete(url, config);
    return response.data;
  }
}

export const httpClient = new HttpClient();
export default httpClient;`;

  await fs.writeFile(path.join(outputDir, 'src/services/http-client.ts'), httpContent);
}

async function generateTestSetup(outputDir, options) {
  // Generate Jest configuration
  const jestConfig = `module.exports = {
  testEnvironment: 'jsdom',
  setupFilesAfterEnv: ['<rootDir>/src/setupTests.ts'],
  moduleNameMapping: {
    '\\\\.(css|less|scss|sass)$': 'identity-obj-proxy',
  },
  transform: {
    '^.+\\\\.(ts|tsx)$': 'ts-jest',
  },
  collectCoverageFrom: [
    'src/**/*.{ts,tsx}',
    '!src/**/*.d.ts',
    '!src/main.tsx',
    '!src/vite-env.d.ts',
  ],
  coverageThreshold: {
    global: {
      branches: 70,
      functions: 70,
      lines: 70,
      statements: 70,
    },
  },
};`;

  await fs.writeFile(path.join(outputDir, 'jest.config.js'), jestConfig);

  // Generate test setup file
  const setupTests = `import '@testing-library/jest-dom';

// Mock IntersectionObserver
global.IntersectionObserver = class IntersectionObserver {
  constructor() {}
  disconnect() {}
  observe() {}
  unobserve() {}
};

// Mock ResizeObserver
global.ResizeObserver = class ResizeObserver {
  constructor() {}
  disconnect() {}
  observe() {}
  unobserve() {}
};

// Mock matchMedia
Object.defineProperty(window, 'matchMedia', {
  writable: true,
  value: jest.fn().mockImplementation(query => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: jest.fn(),
    removeListener: jest.fn(),
    addEventListener: jest.fn(),
    removeEventListener: jest.fn(),
    dispatchEvent: jest.fn(),
  })),
});`;

  await fs.writeFile(path.join(outputDir, 'src/setupTests.ts'), setupTests);

  // Generate test utilities
  const testUtils = `import React, { ReactElement } from 'react';
import { render, RenderOptions } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';

// Custom render function that includes providers
const AllTheProviders = ({ children }: { children: React.ReactNode }) => {
  return (
    <BrowserRouter>
      {children}
    </BrowserRouter>
  );
};

const customRender = (
  ui: ReactElement,
  options?: Omit<RenderOptions, 'wrapper'>
) => render(ui, { wrapper: AllTheProviders, ...options });

export * from '@testing-library/react';
export { customRender as render };`;

  await fs.writeFile(path.join(outputDir, 'src/utils/test-utils.tsx'), testUtils);

  // Generate basic CSS files
  const indexCss = `body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

code {
  font-family: source-code-pro, Menlo, Monaco, Consolas, 'Courier New',
    monospace;
}

* {
  box-sizing: border-box;
}`;

  await fs.writeFile(path.join(outputDir, 'src/styles/index.css'), indexCss);

  const appCss = `.App {
  text-align: center;
}

.App-header {
  background-color: #282c34;
  padding: 20px;
  color: white;
}

.App-header h1 {
  margin: 0 0 10px 0;
}

main {
  padding: 20px;
}`;

  await fs.writeFile(path.join(outputDir, 'src/styles/App.css'), appCss);
}

module.exports = { generateReactProject };
