const { AngularToReactCodemod } = require('../src/index');
const fs = require('fs-extra');
const path = require('path');

// Test examples for the Angular to React codemod
async function runTestExamples() {
  console.log('🧪 Running Angular to React codemod test examples...\n');

  // Create test Angular files
  await createTestAngularFiles();

  // Run the codemod
  const codemod = new AngularToReactCodemod({
    sourceDir: './tests/angular-example',
    outputDir: './tests/react-output',
    generateTests: true,
    useTypeScript: true
  });

  try {
    await codemod.transform();
    console.log('✅ Test examples completed successfully!');
  } catch (error) {
    console.error('❌ Test examples failed:', error);
  }
}

async function createTestAngularFiles() {
  const testDir = './tests/angular-example';
  await fs.ensureDir(testDir);

  // Create test component
  const componentContent = `import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { UserService } from './user.service';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {
  @Input() userId: string;
  @Output() userSelected = new EventEmitter<string>();

  user: any = null;
  loading = false;
  error: string | null = null;

  constructor(private userService: UserService) {}

  ngOnInit() {
    this.loadUser();
  }

  async loadUser() {
    if (!this.userId) return;
    
    this.loading = true;
    this.error = null;
    
    try {
      this.user = await this.userService.getUser(this.userId);
    } catch (err) {
      this.error = 'Failed to load user';
    } finally {
      this.loading = false;
    }
  }

  onSelectUser() {
    this.userSelected.emit(this.userId);
  }

  onUpdateUser(userData: any) {
    this.userService.updateUser(this.userId, userData);
  }
}`;

  await fs.writeFile(path.join(testDir, 'user-profile.component.ts'), componentContent);

  // Create test template
  const templateContent = `<div class="user-profile" [ngClass]="{'loading': loading}">
  <h2>User Profile</h2>
  
  <div *ngIf="loading" class="spinner">
    Loading...
  </div>
  
  <div *ngIf="error" class="error">
    {{ error }}
  </div>
  
  <div *ngIf="user && !loading" class="user-info">
    <h3>{{ user.name | titlecase }}</h3>
    <p>Email: {{ user.email | lowercase }}</p>
    <p>Joined: {{ user.createdAt | date:'mediumDate' }}</p>
    
    <button (click)="onSelectUser()" 
            [disabled]="loading"
            class="btn btn-primary">
      Select User
    </button>
    
    <button (click)="onUpdateUser({name: 'Updated Name'})"
            class="btn btn-secondary">
      Update User
    </button>
  </div>
  
  <ng-container *ngFor="let item of user?.items; let i = index">
    <div class="item" [attr.data-index]="i">
      {{ item.name }} - {{ item.price | currency }}
    </div>
  </ng-container>
</div>`;

  await fs.writeFile(path.join(testDir, 'user-profile.component.html'), templateContent);

  // Create test service
  const serviceContent = `import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private usersSubject = new BehaviorSubject<any[]>([]);
  public users$ = this.usersSubject.asObservable();

  constructor(private http: HttpClient) {}

  async getUser(id: string): Promise<any> {
    return this.http.get(\`/api/users/\${id}\`).toPromise();
  }

  async updateUser(id: string, userData: any): Promise<any> {
    const result = await this.http.put(\`/api/users/\${id}\`, userData).toPromise();
    this.refreshUsers();
    return result;
  }

  async createUser(userData: any): Promise<any> {
    const result = await this.http.post('/api/users', userData).toPromise();
    this.refreshUsers();
    return result;
  }

  async deleteUser(id: string): Promise<void> {
    await this.http.delete(\`/api/users/\${id}\`).toPromise();
    this.refreshUsers();
  }

  private refreshUsers() {
    this.http.get<any[]>('/api/users').subscribe(users => {
      this.usersSubject.next(users);
    });
  }

  getUsersStream(): Observable<any[]> {
    return this.users$;
  }
}`;

  await fs.writeFile(path.join(testDir, 'user.service.ts'), serviceContent);

  // Create test directive
  const directiveContent = `import { Directive, ElementRef, Input, HostListener } from '@angular/core';

@Directive({
  selector: '[appHighlight]'
})
export class HighlightDirective {
  @Input() appHighlight = '';
  @Input() defaultColor = 'yellow';

  constructor(private el: ElementRef) {}

  @HostListener('mouseenter') onMouseEnter() {
    this.highlight(this.appHighlight || this.defaultColor);
  }

  @HostListener('mouseleave') onMouseLeave() {
    this.highlight('');
  }

  private highlight(color: string) {
    this.el.nativeElement.style.backgroundColor = color;
  }
}`;

  await fs.writeFile(path.join(testDir, 'highlight.directive.ts'), directiveContent);

  // Create test pipe
  const pipeContent = `import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'truncate',
  pure: true
})
export class TruncatePipe implements PipeTransform {
  transform(value: string, limit = 25, completeWords = false, ellipsis = '...'): string {
    if (!value) return '';
    
    if (value.length <= limit) {
      return value;
    }
    
    if (completeWords) {
      limit = value.substr(0, limit).lastIndexOf(' ');
    }
    
    return value.substr(0, limit) + ellipsis;
  }
}`;

  await fs.writeFile(path.join(testDir, 'truncate.pipe.ts'), pipeContent);

  // Create test module
  const moduleContent = `import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { UserProfileComponent } from './user-profile.component';
import { HighlightDirective } from './highlight.directive';
import { TruncatePipe } from './truncate.pipe';
import { UserService } from './user.service';

const routes: Routes = [
  { path: '', component: UserProfileComponent },
  { path: 'profile/:id', component: UserProfileComponent },
  { path: '**', redirectTo: '' }
];

@NgModule({
  declarations: [
    UserProfileComponent,
    HighlightDirective,
    TruncatePipe
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  providers: [
    UserService
  ],
  exports: [
    UserProfileComponent,
    HighlightDirective,
    TruncatePipe
  ]
})
export class UserModule { }`;

  await fs.writeFile(path.join(testDir, 'user.module.ts'), moduleContent);

  // Create package.json for the test
  const packageJson = {
    name: "angular-test-app",
    version: "1.0.0",
    dependencies: {
      "@angular/core": "^15.0.0",
      "@angular/common": "^15.0.0",
      "@angular/router": "^15.0.0",
      "@angular/common/http": "^15.0.0",
      "rxjs": "^7.5.0"
    }
  };

  await fs.writeJson(path.join(testDir, '../package.json'), packageJson, { spaces: 2 });

  console.log('📁 Created test Angular files');
}

// Run the test if this file is executed directly
if (require.main === module) {
  runTestExamples().catch(console.error);
}

module.exports = { runTestExamples, createTestAngularFiles };
