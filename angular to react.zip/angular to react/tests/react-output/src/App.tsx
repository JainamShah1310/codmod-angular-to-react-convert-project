import React from 'react';
import { Routes, Route } from 'react-router-dom';
import './styles/App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>React App (Converted from Angular)</h1>
        <p>
          This application has been converted from Angular to React.
        </p>
      </header>
      <main>
        <Routes>
          <Route path="/" element={<div>Home Page</div>} />
          <Route path="*" element={<div>Page Not Found</div>} />
        </Routes>
      </main>
    </div>
  );
}

export default App;