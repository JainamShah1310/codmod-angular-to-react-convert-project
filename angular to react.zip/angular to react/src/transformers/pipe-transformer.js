const { parse } = require('@babel/parser');
const traverse = require('@babel/traverse').default;
const generate = require('@babel/generator').default;
const t = require('@babel/types');

async function transformAngularPipe(content, filePath, options = {}) {
  try {
    const ast = parse(content, {
      sourceType: 'module',
      plugins: ['typescript', 'decorators-legacy', 'classProperties']
    });

    let pipeMetadata = {};
    let pipeClass = null;

    // Extract pipe metadata and class
    traverse(ast, {
      Decorator(path) {
        if (t.isIdentifier(path.node.expression.callee, { name: 'Pipe' })) {
          const properties = path.node.expression.arguments[0].properties;
          properties.forEach(prop => {
            if (t.isIdentifier(prop.key)) {
              const key = prop.key.name;
              if (key === 'name') {
                pipeMetadata.name = prop.value.value;
              } else if (key === 'pure') {
                pipeMetadata.pure = prop.value.value;
              }
            }
          });
        }
      },
      ClassDeclaration(path) {
        if (path.node.decorators && path.node.decorators.some(dec => 
          t.isCallExpression(dec.expression) && 
          t.isIdentifier(dec.expression.callee, { name: 'Pipe' })
        )) {
          pipeClass = path.node;
        }
      }
    });

    if (!pipeClass) {
      throw new Error('No Angular pipe found in file');
    }

    // Find the transform method
    const transformMethod = findTransformMethod(pipeClass);
    if (!transformMethod) {
      throw new Error('No transform method found in pipe');
    }

    // Generate React equivalent
    const { reactCode, testCode } = generateReactPipe(
      pipeClass, 
      pipeMetadata, 
      transformMethod, 
      options
    );

    return {
      code: reactCode,
      testCode,
      metadata: pipeMetadata
    };

  } catch (error) {
    console.error(`Error transforming pipe ${filePath}:`, error);
    throw error;
  }
}

function findTransformMethod(pipeClass) {
  return pipeClass.body.body.find(member => 
    t.isClassMethod(member) && 
    t.isIdentifier(member.key, { name: 'transform' })
  );
}

function generateReactPipe(pipeClass, metadata, transformMethod, options) {
  const pipeName = (pipeClass.name ? pipeClass.name.name : 'Unknown').replace(/Pipe$/, '');
  const functionName = `${pipeName.toLowerCase()}Pipe`;
  const hookName = `use${pipeName}Pipe`;
  
  // Extract transform method parameters and body
  const params = transformMethod && transformMethod.value ? transformMethod.value.params : [];
  const body = transformMethod && transformMethod.value ? transformMethod.value.body : null;
  const bodyCode = body ? generate(body).code : '{ return value; }';
  
  // Generate utility function
  const utilityFunction = generateUtilityFunction(functionName, params, bodyCode);
  
  // Generate hook version (for memoization if pipe is pure)
  const hookFunction = generateHookFunction(hookName, functionName, params, metadata.pure);
  
  // Generate React component version (for template usage)
  const componentFunction = generateComponentFunction(pipeName, functionName, params);

  const reactCode = `import { useMemo, useCallback } from 'react';

${utilityFunction}

${hookFunction}

${componentFunction}

// Export all versions
export { ${functionName}, ${hookName}, ${pipeName}Pipe };
export default ${functionName};`;

  const testCode = generatePipeTest(pipeName, functionName, hookName, params);
  
  return { reactCode, testCode };
}

function generateUtilityFunction(functionName, params, bodyCode) {
  const paramNames = params.map(param => {
    if (t.isIdentifier(param)) {
      return param.name;
    } else if (t.isAssignmentPattern(param)) {
      return param.left.name;
    }
    return 'param';
  });

  const paramList = paramNames.join(', ');

  return `// Pure utility function version
export const ${functionName} = (${paramList}) => {
${bodyCode.slice(1, -1)} // Remove braces from original method body
};`;
}

function generateHookFunction(hookName, functionName, params, isPure = true) {
  const paramNames = params.map(param => {
    if (t.isIdentifier(param)) {
      return param.name;
    } else if (t.isAssignmentPattern(param)) {
      return param.left.name;
    }
    return 'param';
  });

  const paramList = paramNames.join(', ');
  const dependencyList = paramNames.join(', ');

  if (isPure) {
    return `// Memoized hook version (for pure pipes)
export const ${hookName} = (${paramList}) => {
  return useMemo(() => ${functionName}(${paramList}), [${dependencyList}]);
};`;
  } else {
    return `// Hook version (for impure pipes)
export const ${hookName} = (${paramList}) => {
  return useCallback(() => ${functionName}(${paramList}), [${dependencyList}]);
};`;
  }
}

function generateComponentFunction(pipeName, functionName, params) {
  const paramNames = params.map(param => {
    if (t.isIdentifier(param)) {
      return param.name;
    } else if (t.isAssignmentPattern(param)) {
      return param.left.name;
    }
    return 'param';
  });

  const propsInterface = paramNames.map(name => `  ${name}?: any;`).join('\n');
  const paramList = paramNames.join(', ');

  return `// Component version (for JSX usage)
interface ${pipeName}PipeProps {
${propsInterface}
  children?: (result: any) => React.ReactNode;
}

export const ${pipeName}Pipe: React.FC<${pipeName}PipeProps> = ({ 
  ${paramList}, 
  children 
}) => {
  const result = ${functionName}(${paramList});
  
  if (children) {
    return <>{children(result)}</>;
  }
  
  return <>{result}</>;
};`;
}

function generatePipeTest(pipeName, functionName, hookName, params) {
  const testParams = params.map((param, index) => {
    if (t.isIdentifier(param)) {
      return generateTestValue(param.name, index);
    } else if (t.isAssignmentPattern(param)) {
      return generateTestValue(param.left.name, index);
    }
    return `testValue${index}`;
  });

  return `import { renderHook } from '@testing-library/react';
import { ${functionName}, ${hookName}, ${pipeName}Pipe } from './${pipeName}Pipe';

describe('${pipeName}Pipe', () => {
  const testData = {
${testParams.map((value, index) => `    param${index}: ${value}`).join(',\n')}
  };

  describe('${functionName}', () => {
    it('should transform value correctly', () => {
      const result = ${functionName}(${testParams.join(', ')});
      expect(result).toBeDefined();
      // Add specific assertions based on pipe logic
    });

    it('should handle edge cases', () => {
      const result = ${functionName}(null);
      expect(result).toBeDefined();
    });
  });

  describe('${hookName}', () => {
    it('should return memoized result', () => {
      const { result, rerender } = renderHook(
        ({ ${testParams.map((_, i) => `param${i}`).join(', ')} }) => 
          ${hookName}(${testParams.map((_, i) => `param${i}`).join(', ')}),
        { initialProps: testData }
      );

      const firstResult = result.current;
      rerender(testData); // Same props
      expect(result.current).toBe(firstResult); // Should be memoized
    });
  });

  describe('${pipeName}Pipe Component', () => {
    it('should render transformed value', () => {
      const { container } = render(
        <${pipeName}Pipe ${testParams.map((value, i) => `param${i}={${value}}`).join(' ')} />
      );
      
      expect(container.textContent).toBeDefined();
    });

    it('should work with render prop pattern', () => {
      const { container } = render(
        <${pipeName}Pipe ${testParams.map((value, i) => `param${i}={${value}}`).join(' ')}>
          {(result) => <span data-testid="result">{result}</span>}
        </${pipeName}Pipe>
      );
      
      expect(screen.getByTestId('result')).toBeInTheDocument();
    });
  });
});`;
}

function generateTestValue(paramName, index) {
  // Generate appropriate test values based on common parameter names
  const name = paramName.toLowerCase();
  
  if (name.includes('date')) {
    return 'new Date()';
  } else if (name.includes('number') || name.includes('count') || name.includes('amount')) {
    return '123';
  } else if (name.includes('string') || name.includes('text') || name.includes('name')) {
    return "'test string'";
  } else if (name.includes('array') || name.includes('list') || name.includes('items')) {
    return '[1, 2, 3]';
  } else if (name.includes('object') || name.includes('data')) {
    return '{ key: "value" }';
  } else if (name.includes('boolean') || name.includes('flag')) {
    return 'true';
  }
  
  // Default test values based on index
  const defaults = ["'test'", '42', 'true', '[]', '{}'];
  return defaults[index % defaults.length];
}

// Common Angular pipes implementations for reference
const COMMON_PIPES = {
  DatePipe: `// Date pipe implementation
export const datePipe = (value, format = 'mediumDate', locale = 'en-US') => {
  if (!value) return '';
  const date = new Date(value);
  return new Intl.DateTimeFormat(locale, getDateFormatOptions(format)).format(date);
};

function getDateFormatOptions(format) {
  const formats = {
    'short': { year: '2-digit', month: 'numeric', day: 'numeric' },
    'medium': { year: 'numeric', month: 'short', day: 'numeric' },
    'long': { year: 'numeric', month: 'long', day: 'numeric' },
    'full': { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }
  };
  return formats[format] || formats.medium;
}`,

  CurrencyPipe: `// Currency pipe implementation
export const currencyPipe = (value, currencyCode = 'USD', display = 'symbol', locale = 'en-US') => {
  if (value == null) return '';
  return new Intl.NumberFormat(locale, {
    style: 'currency',
    currency: currencyCode,
    currencyDisplay: display
  }).format(value);
};`,

  DecimalPipe: `// Decimal pipe implementation
export const decimalPipe = (value, digitsInfo = '1.0-3', locale = 'en-US') => {
  if (value == null) return '';
  const [minInt, fracInfo] = digitsInfo.split('.');
  const [minFrac, maxFrac] = fracInfo ? fracInfo.split('-') : ['0', '3'];
  
  return new Intl.NumberFormat(locale, {
    minimumIntegerDigits: parseInt(minInt) || 1,
    minimumFractionDigits: parseInt(minFrac) || 0,
    maximumFractionDigits: parseInt(maxFrac) || 3
  }).format(value);
};`,

  PercentPipe: `// Percent pipe implementation
export const percentPipe = (value, digitsInfo = '1.0-0', locale = 'en-US') => {
  if (value == null) return '';
  const [minInt, fracInfo] = digitsInfo.split('.');
  const [minFrac, maxFrac] = fracInfo ? fracInfo.split('-') : ['0', '0'];
  
  return new Intl.NumberFormat(locale, {
    style: 'percent',
    minimumIntegerDigits: parseInt(minInt) || 1,
    minimumFractionDigits: parseInt(minFrac) || 0,
    maximumFractionDigits: parseInt(maxFrac) || 0
  }).format(value);
};`,

  UpperCasePipe: `// Uppercase pipe implementation
export const upperCasePipe = (value) => {
  if (value == null) return '';
  return String(value).toUpperCase();
};`,

  LowerCasePipe: `// Lowercase pipe implementation
export const lowerCasePipe = (value) => {
  if (value == null) return '';
  return String(value).toLowerCase();
};`,

  TitleCasePipe: `// Title case pipe implementation
export const titleCasePipe = (value) => {
  if (value == null) return '';
  return String(value).replace(/\\w\\S*/g, (txt) => 
    txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase()
  );
};`,

  SlicePipe: `// Slice pipe implementation
export const slicePipe = (value, start, end) => {
  if (value == null) return value;
  if (Array.isArray(value) || typeof value === 'string') {
    return value.slice(start, end);
  }
  return value;
};`,

  JsonPipe: `// JSON pipe implementation
export const jsonPipe = (value) => {
  return JSON.stringify(value, null, 2);
};`
};

function getCommonPipeImplementation(pipeName) {
  return COMMON_PIPES[pipeName] || null;
}

module.exports = { 
  transformAngularPipe, 
  COMMON_PIPES, 
  getCommonPipeImplementation 
};
