// Core dependencies for file system operations and pattern matching
const fs = require('fs-extra');
const path = require('path');
const glob = require('glob');

/**
 * Analyzes an Angular project to identify and categorize all files
 * This is the first step in the transformation process - understanding the project structure
 * @param {string} sourceDir - Path to the Angular source directory
 * @returns {Object} Analysis results with categorized file lists and project metadata
 */
async function analyzeAngularProject(sourceDir) {
  // Initialize analysis results object to store all discovered files and metadata
  const analysis = {
    totalFiles: 0,        // Total count of all files found
    components: [],       // Angular @Component decorated classes
    services: [],         // Angular @Injectable decorated classes  
    templates: [],        // HTML template files (.html)
    modules: [],          // Angular @NgModule decorated classes
    directives: [],       // Angular @Directive decorated classes
    pipes: [],            // Angular @Pipe decorated classes
    routing: [],          // Routing configuration files
    assets: [],           // Static assets (images, fonts, etc.)
    dependencies: {},     // Package.json dependencies
    angularVersion: null  // Detected Angular version from package.json
  };

  try {
    // Step 1: Read package.json to understand project dependencies and detect Angular version
    const packageJsonPath = path.join(sourceDir, '../package.json');
    if (await fs.pathExists(packageJsonPath)) {
      const packageJson = await fs.readJson(packageJsonPath);
      analysis.dependencies = { ...packageJson.dependencies, ...packageJson.devDependencies };
      
      // Extract Angular version for compatibility checks during transformation
      if (analysis.dependencies['@angular/core']) {
        analysis.angularVersion = analysis.dependencies['@angular/core'];
      }
    }

    // Step 2: Discover all relevant files using glob patterns
    // Find TypeScript files (excluding test and declaration files)
    const tsFiles = glob.sync('**/*.ts', { cwd: sourceDir, ignore: ['**/*.spec.ts', '**/*.d.ts'] });
    // Find JavaScript files (excluding test files)
    const jsFiles = glob.sync('**/*.js', { cwd: sourceDir, ignore: ['**/*.spec.js'] });
    // Find HTML template files
    const htmlFiles = glob.sync('**/*.html', { cwd: sourceDir });
    // Find CSS/SCSS/SASS/LESS style files
    const cssFiles = glob.sync('**/*.{css,scss,sass,less}', { cwd: sourceDir });

    // Calculate total file count for progress reporting
    analysis.totalFiles = tsFiles.length + jsFiles.length + htmlFiles.length + cssFiles.length;

    // Step 3: Analyze TypeScript/JavaScript files to categorize them by Angular constructs
    for (const file of [...tsFiles, ...jsFiles]) {
      const filePath = path.join(sourceDir, file);
      const content = await fs.readFile(filePath, 'utf8');
      
      // Use pattern matching to identify different Angular file types
      if (isAngularComponent(content)) {
        analysis.components.push(filePath);
      } else if (isAngularService(content)) {
        analysis.services.push(filePath);
      } else if (isAngularModule(content)) {
        analysis.modules.push(filePath);
      } else if (isAngularDirective(content)) {
        analysis.directives.push(filePath);
      } else if (isAngularPipe(content)) {
        analysis.pipes.push(filePath);
      } else if (isRoutingModule(content)) {
        analysis.routing.push(filePath);
      }
    }

    // Step 4: Collect all HTML template files (will be converted to JSX)
    for (const file of htmlFiles) {
      const filePath = path.join(sourceDir, file);
      analysis.templates.push(filePath);
    }

    // Step 5: Discover static assets that need to be copied to React project
    const assetPatterns = ['**/*.{png,jpg,jpeg,gif,svg,ico}', '**/*.{json,xml}'];
    for (const pattern of assetPatterns) {
      const assets = glob.sync(pattern, { cwd: sourceDir });
      analysis.assets.push(...assets.map(asset => path.join(sourceDir, asset)));
    }

  } catch (error) {
    console.error('Error analyzing Angular project:', error);
    throw error;
  }

  return analysis;
}

/**
 * Detects if a file contains an Angular component by looking for @Component decorator
 * Components must have a selector and either template or templateUrl
 * @param {string} content - File content to analyze
 * @returns {boolean} True if file contains an Angular component
 */
function isAngularComponent(content) {
  return content.includes('@Component') && 
         (content.includes('templateUrl') || content.includes('template')) &&
         content.includes('selector');
}

/**
 * Detects if a file contains an Angular service by looking for @Injectable decorator
 * Services are typically provided in root or have injectable metadata
 * @param {string} content - File content to analyze
 * @returns {boolean} True if file contains an Angular service
 */
function isAngularService(content) {
  return content.includes('@Injectable') || 
         (content.includes('providedIn') && content.includes('root'));
}

/**
 * Detects if a file contains an Angular module by looking for @NgModule decorator
 * Modules must have declarations, imports, or providers arrays
 * @param {string} content - File content to analyze
 * @returns {boolean} True if file contains an Angular module
 */
function isAngularModule(content) {
  return content.includes('@NgModule') &&
         (content.includes('declarations') || content.includes('imports') || content.includes('providers'));
}

/**
 * Detects if a file contains an Angular directive by looking for @Directive decorator
 * Directives must have a selector for DOM element targeting
 * @param {string} content - File content to analyze
 * @returns {boolean} True if file contains an Angular directive
 */
function isAngularDirective(content) {
  return content.includes('@Directive') && content.includes('selector');
}

/**
 * Detects if a file contains an Angular pipe by looking for @Pipe decorator
 * Pipes must have a name and implement the transform method
 * @param {string} content - File content to analyze
 * @returns {boolean} True if file contains an Angular pipe
 */
function isAngularPipe(content) {
  return content.includes('@Pipe') && 
         content.includes('name') && 
         content.includes('transform');
}

/**
 * Detects if a file contains Angular routing configuration
 * Routing modules use RouterModule.forRoot() or forChild() with routes array
 * @param {string} content - File content to analyze
 * @returns {boolean} True if file contains routing configuration
 */
function isRoutingModule(content) {
  return content.includes('RouterModule') && 
         (content.includes('forRoot') || content.includes('forChild')) &&
         content.includes('routes');
}

function analyzeComponentDependencies(content) {
  const dependencies = {
    imports: [],
    services: [],
    components: [],
    directives: [],
    pipes: []
  };

  // Extract imports
  const importRegex = /import\s+{([^}]+)}\s+from\s+['"]([^'"]+)['"]/g;
  let match;
  while ((match = importRegex.exec(content)) !== null) {
    const imports = match[1].split(',').map(imp => imp.trim());
    dependencies.imports.push({
      items: imports,
      from: match[2]
    });
  }

  // Extract constructor dependencies (services)
  const constructorRegex = /constructor\s*\(\s*([^)]*)\s*\)/;
  const constructorMatch = content.match(constructorRegex);
  if (constructorMatch) {
    const params = constructorMatch[1].split(',');
    params.forEach(param => {
      const parts = param.trim().split(':');
      if (parts.length === 2) {
        dependencies.services.push(parts[1].trim());
      }
    });
  }

  return dependencies;
}

function analyzeTemplateFeatures(content) {
  const features = {
    directives: [],
    pipes: [],
    eventBindings: [],
    propertyBindings: [],
    twoWayBindings: [],
    structuralDirectives: []
  };

  // Common Angular directives
  const directivePatterns = [
    /\*ngFor/g,
    /\*ngIf/g,
    /\*ngSwitch/g,
    /ngClass/g,
    /ngStyle/g,
    /ngModel/g,
    /routerLink/g,
    /routerOutlet/g
  ];

  directivePatterns.forEach(pattern => {
    const matches = content.match(pattern);
    if (matches) {
      features.directives.push(...matches);
    }
  });

  // Extract pipes
  const pipeRegex = /\|\s*(\w+)/g;
  let pipeMatch;
  while ((pipeMatch = pipeRegex.exec(content)) !== null) {
    features.pipes.push(pipeMatch[1]);
  }

  // Extract event bindings
  const eventRegex = /\((\w+)\)=/g;
  let eventMatch;
  while ((eventMatch = eventRegex.exec(content)) !== null) {
    features.eventBindings.push(eventMatch[1]);
  }

  // Extract property bindings
  const propRegex = /\[(\w+)\]=/g;
  let propMatch;
  while ((propMatch = propRegex.exec(content)) !== null) {
    features.propertyBindings.push(propMatch[1]);
  }

  return features;
}

module.exports = {
  analyzeAngularProject,
  analyzeComponentDependencies,
  analyzeTemplateFeatures,
  isAngularComponent,
  isAngularService,
  isAngularModule,
  isAngularDirective,
  isAngularPipe
};
